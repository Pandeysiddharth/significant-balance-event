# Real-Time Money Movement Tracking for RMs
## Architecture Overview — WRB-Owned ODS on Databricks

**Databricks × Standard Chartered Bank (WRB Architecture)**
Prepared by: Siddharth Pandey, Lead Solutions Architect, Databricks
Date: 22 Oct 2026 · Draft v0.1 · Follows the 21 Oct 2026 architecture session with Habeeb, Mario, Dhas and Kiran

---

## 1. Purpose and scope

This document describes how to build the solution demonstrated on 21 Oct: a WRB-owned Operational Data Store (ODS) on Databricks that detects significant balance events and surfaces them to Relationship Managers within minutes rather than days.

It covers the **Release 1** target (consume SCB's existing Solace/Kafka topics on Databricks, persist and process in Unity Catalog, serve to RMs and flow back on-prem), the delivery phases, the cross-cutting requirements SCB raised (PII tokenization, pattern approval, portability, connectivity), and the open decisions that gate each phase. **Release 2** (Zerobus) is described as an evaluation track only, per Dhas's position that it is a source-team ecosystem change and not an approved real-time pattern.

Scope boundaries agreed in the session:

- GDP / EDMP is **not** touched or replaced; the ODS sits beside it and optionally feeds it.
- This is a tailored WRB build, not a replacement for the on-prem Postgres / SpringWatch ODS that WRB is already building. The two can coexist, with the persistence model to be decided (Section 8).
- Key-value lookups (latest balance, last 10 transactions) stay on direct APIs to core systems. The ODS is for analytic logic that should not live inside systems of record.

---

## 2. Business goals and success measures

| Goal | Today | Target | Demo evidence |
|---|---|---|---|
| Signal latency, fast markets (HK, SG) | ~2 days | < 5 min (Habeeb) | < 1 min end-to-end, P50/P95 tested |
| Signal latency, slower markets (e.g. India) | ~1 week | < 5 min | same pipeline, market-agnostic |
| Consumer lag / AI brief latency | n/a | sub-second where possible | ~1 s / < 2 s on architect view |
| Pattern detection for wealth | does not exist | baseline + suppression rules in production | 30-day baseline, 30× norm flag |
| RM actionability | manual | AI brief, pre-call checks, outcome capture | role-based console, NL Q&A |

Two signals from one event:

- **Large inflow** → RM pitches a suitable product (AI selects from product shelf using client history and balances).
- **Large outflow** → RM verifies intent; possible scam, optional hand-off to Fusion / anti-crime.

---

## 3. Design principles

1. **Consume, don't re-plumb.** Release 1 reads the topics SCB already publishes. No producer code changes.
2. **Unity Catalog is the system of persistence; Lakebase and Postgres are serving layers.** Delta tables on SCB's Azure ADLS carry lineage, data quality and access governance. Serving stores are derived and rebuildable.
3. **Tokenize before landing.** PII is tokenized at the edge of the ODS (Bronze → Silver boundary, or upstream in SCB's tokenization service) so no clear-text PII is persisted in cloud.
4. **Portable artifacts.** Pipeline logic is written as standard Spark Structured Streaming (SQL + PySpark) so it can run on SCB's own Spark Streaming engine in markets where cloud is not permitted (China). Genie-generated code is treated as a normal artifact and goes through SCB's repo, build and promotion process.
5. **Flow-back is first-class.** Gold outputs are pushed to on-prem Postgres and emitted as events back to SCB topics, so downstream consumers do not need to call Databricks.
6. **In-tenant, not SaaS-global.** Everything runs in SCB's isolated Azure workspace over VNet with private connectivity.

---

## 4. Target architecture — Release 1

```
 ON-PREM (SCB)                         AZURE (SCB tenant, VNet)                                   CONSUMERS
 ─────────────                         ────────────────────────                                   ─────────

 Core banking         Solace           Kafka topics                 WRB ODS — Unity Catalog
 sources     ──────►  PubSub+  ──────► mirrored to Azure  ──────►  ┌──────────┐ ┌──────────┐ ┌──────────┐
 (deposits,           (uniform         (Kafka bridge /              │  Bronze  │►│  Silver  │►│   Gold   │
  payments,            client)          Event Hubs Kafka            │ raw evts │ │ tokenized│ │ signals  │
  balances)                             endpoint)                   │ + DLQ    │ │ enriched │ │ baseline │
                                                                    └──────────┘ └──────────┘ └────┬─────┘
                                           Spark Structured Streaming (notebooks / DLT)             │
                                           lineage · DQ expectations · UC access control            │
                                                                                                    │
                                        ┌───────────────────────────────────────────────────────────┼─────────────┐
                                        │                                                           ▼             │
                                        │   Lakebase (ms OLTP)  ◄── synced tables ──  Gold signals table         │
                                        │   agent memory, RM lookups                        │                     │
                                        │           │                                       │ JDBC (foreachBatch) │
                                        │           ▼                                       ▼                     │
                                        │   RM console — Databricks Apps          On-prem Postgres ODS  ──► API  │
                                        │   (Genie App Builder)                   (Dhas's requested sink)        │
                                        │   RM · Team lead · Fraud · Architect                                   │
                                        │   NL Q&A via Genie                      Kafka sink ──► SCB topics      │
                                        │   AI brief via Model Serving            (signal events back out)       │
                                        └───────────────────────────────────────────────────────────────────────┘
                                                        │                                     │
                                                        ▼                                     ▼
                                              Fusion / anti-crime               GDP / EDMP (unchanged)
                                              scam signals (optional)           optional Parquet / Iceberg feed
```

### 4.1 Ingestion layer

**Reality:** SCB's real-time events flow over Solace with a uniform, reliable client; a separate team is rolling out Kafka. Spark has no native Solace source, so one of three bridges is needed. This is the first technical decision for the joint platform session.

| Option | How | Pros | Cons |
|---|---|---|---|
| A. Solace → Kafka bridge | Solace PubSub+ Kafka Connector publishes selected Solace topics to the Kafka cluster already being rolled out; Databricks reads Kafka | Aligns with SCB's Kafka programme; standard Spark Kafka source; replay via offsets | Depends on Kafka rollout timeline; one more hop |
| B. Solace → Azure Event Hubs (Kafka endpoint) | Solace bridge to Event Hubs in SCB's Azure tenant; Databricks reads via Kafka protocol | Managed, in-tenant, no cluster to run; same Spark code as A | Event Hubs sits outside the Solace mesh; retention limits |
| C. Direct Solace consumer | Custom Spark source or microservice using Solace JMS/JCSMP writing to Bronze | No bridge | Bespoke code to maintain; weakest portability story |

**Recommendation:** Option A where the Kafka rollout covers WRB topics; Option B as the interim. Both keep the Spark code identical, which protects portability.

Bronze ingestion behaviour:

- `readStream` from Kafka with checkpointing on ADLS; exactly-once to Delta.
- Raw payload preserved as-is (`value` bytes + headers + ingest timestamp) for audit and replay.
- Schema inferred/evolved via Auto Loader-style `schemaEvolutionMode` or explicit Avro/JSON schema from SCB's schema registry.
- Dead-letter: malformed records routed to `bronze.dlq_*` with failure reason; never dropped.

### 4.2 WRB ODS — Unity Catalog (Bronze / Silver / Gold)

Catalog layout (illustrative): `wrb_ods.<market>_bronze`, `wrb_ods.<market>_silver`, `wrb_ods.<market>_gold`, with market segregation supporting residency controls.

| Layer | Content | Key logic |
|---|---|---|
| **Bronze** | Raw core-banking events, one table per topic family (transactions, balances, account events) | Append-only; partitioned by ingest date; retention per market policy |
| **Silver** | Tokenized, deduplicated, typed events; customer and account dimensions (tokenized) | PII tokenization at this boundary (see 6.1); dedupe on event id; late-data watermarking; enrichment with product, segment, RM assignment, do-not-contact, complaint and vulnerability flags |
| **Gold** | `client_30d_baseline`, `significant_balance_events`, `rm_signals`, `signal_suppressions`, `signal_outcomes` | Rolling 30-day baseline per client (stateful streaming aggregation); event flagged when flow exceeds configurable multiple of norm (30× in demo); suppression rules; 4-hour expiry; full lineage from signal back to Bronze row |

Suppression rules are data-driven (a `signal_rules` reference table) rather than hard-coded, so WRB can change thresholds and add rules without a code release. Rules shown in the demo: do-not-contact preference, active complaint, vulnerable customer, already contacted 3× in 2 days, expiry after 4 hours.

Data quality: DLT expectations or equivalent assertions on Silver (non-null client token, valid currency, amount range) with quarantine rather than fail-stop for the latency-sensitive path.

### 4.3 Serving layer

- **Lakebase** (Postgres-compatible, managed): synced tables from `rm_signals` and client context for millisecond lookups from the console and as agent memory. Parallel option to the on-prem Postgres; both can be fed from the same Gold tables.
- **On-prem Postgres ODS sink:** Structured Streaming `foreachBatch` writes Gold deltas over JDBC through private connectivity; idempotent upserts keyed on `signal_id`. API exposure from the ODS remains SCB-owned.
- **Event emit-back:** Kafka sink publishes `signal.created`, `signal.suppressed`, `signal.expired` events to SCB topics so Fusion, CRM or SpringWatch can subscribe without calling Databricks.
- **GDP / EDMP feed (optional):** scheduled Parquet or Iceberg (UniForm) export of Gold tables to the batch estate.

### 4.4 RM console and AI layer

- **Databricks App (Genie App Builder)** with role-based views: RM (signal list, AI brief, suggested products, pre-call checks, outcome capture), Team lead (created vs suppressed, response rates), Fraud (fraud-tagged signals), Architect (live latency from signal to console).
- **AI brief:** Model Serving endpoint (Foundation Model API or SCB-approved model) grounded strictly in SQL-retrievable context: prior interactions, balances, product shelf, open complaints, preferred language. No free-form generation without a cited source row.
- **NL Q&A:** Genie space over Gold with curated semantic layer and benchmark questions ("clients that moved more than 2× normal this week", "signals not acted on expiring in the next hour").
- **Outcome capture:** console writes to `signal_outcomes` (Lakebase → synced back to UC), closing the loop for suppression ("contacted 3× in 2 days") and for model evaluation.

---

## 5. Release 2 — Zerobus (evaluation track)

Zerobus lets sources write directly to Delta via SDK, removing the broker hop where Databricks is the sink. Reference outcomes (Bosch, production): ~15% better latency, >40% cost saving, components to maintain reduced from 6 to 2.

SCB position (Dhas): requires refactoring producers off the uniform Solace client; source teams resist code changes; not yet an approved real-time pattern (Anti-Crime POC only).

**Approach:** keep as a parallel evaluation owned by Dhas. Candidate pilot: one new source or one greenfield topic where no Solace client exists yet. No Release 1 dependency.

---

## 6. Cross-cutting design

### 6.1 PII and tokenization (action item: add to design)

- **Where:** tokenize at the Bronze → Silver boundary inside SCB's VNet, before data is persisted beyond the raw landing zone. Preferred: call SCB's existing enterprise tokenization service; fallback: format-preserving tokenization UDF with keys held in SCB Key Vault.
- **What:** customer identifiers, account numbers, names, counterparty details, free-text narrations. Amounts, timestamps, product codes and market remain in clear for analytics.
- **Bronze retention:** raw Bronze holds untokenized payloads only if SCB policy permits; otherwise tokenize in the Kafka bridge or at `readStream` time and treat Bronze as already tokenized.
- **Detokenization:** only in the serving path for authorised RM roles, via UC column masks and row filters tied to SCB AD groups; never in Genie or in the AI brief prompt.
- **Residency:** market-level catalogs and ADLS containers so per-country controls (and China's no-cloud constraint) are enforced at the storage boundary.

### 6.2 Networking and connectivity (joint platform session)

Three paths to confirm with SCB's cloud platform network contact:

1. **Inbound events:** on-prem Solace/Kafka → Azure VNet (ExpressRoute / VPN already in place for Kafka mirroring).
2. **Outbound JDBC:** Databricks compute → on-prem Postgres. Requires NCC / private endpoint and firewall allow-list; drives the "approved pattern" ask for Databricks sourcing from business-application databases.
3. **Agent tool-calling egress:** Databricks Apps / Model Serving → on-prem APIs. Known blocker from the CIB thread; separate workstream, report back.

### 6.3 Portability (China and non-cloud markets)

- Write pipelines as plain Spark Structured Streaming notebooks (SQL + PySpark). Avoid DLT-only syntax in the portable core, or maintain DLT as a thin wrapper around portable functions.
- Delta Lake OSS on the target engine; UniForm/Iceberg where SCB's engine prefers Iceberg.
- Proof point for the demo account: extract generated artifacts and run them on SCB's Spark Streaming cluster against sample topics.

### 6.4 Governance and lineage

- UC lineage from `rm_signals` row → Gold aggregation → Silver events → Bronze Kafka offset. This is the artifact Dhas asked to see; share the aggregation notebooks and lineage graph.
- Audit of who saw which signal (console access logs + UC audit logs) for conduct and complaints.
- Model/AI governance: brief prompts, grounding sources and outputs logged to an inference table for review.

### 6.5 Engineering practice

- Repo-first: all notebooks, Genie definitions, app code and rules tables as code in SCB's Git, deployed via Databricks Asset Bundles through dev → UAT → prod.
- Genie-generated code lands as a PR like any other artifact.
- Observability: streaming lag, end-to-end latency (event timestamp → console timestamp), DLQ counts, suppression rates, as the Architect view and as alerts.

---

## 7. Delivery phases

| Phase | Weeks (indicative) | Scope | Exit criteria | Gating decisions |
|---|---|---|---|---|
| **0 — Enablement** | 1–2 | Demo account and tutorials for WRB team; share demo aggregation/lineage code; joint network session; pattern approval request raised | WRB engineers hands-on; connectivity paths mapped; network contact named | Dhas/Habeeb: network contact; Habeeb: pattern approval |
| **1 — Ingest** | 3–5 | Solace→Kafka (or Event Hubs) bridge for 2–3 WRB topics in one market (HK or SG); Bronze + DLQ; Silver with tokenization | Events landing in UC within seconds; tokenization validated by SCB security | Bridge option (A/B); tokenization service availability |
| **2 — Signals** | 5–7 | Gold baseline + significant balance events + rules table + suppression + expiry; lineage verified | Rules reproduce demo behaviour on real (tokenized) data; P95 latency < 5 min measured | Threshold and rule ownership in WRB |
| **3 — Serve & flow-back** | 7–9 | Lakebase synced tables; JDBC sink to on-prem Postgres; Kafka emit-back; GDP export (optional) | Signals visible in on-prem ODS and on SCB topics; idempotency tested | ODS persistence model (Section 8.1) |
| **4 — Console & AI** | 8–10 | Databricks App with four roles; AI brief grounded in SQL; Genie NL Q&A; outcome capture | RM UAT in pilot market; grounding and masking reviewed | Model approval; detokenization roles |
| **5 — Pilot & harden** | 10–13 | Pilot RMs in HK/SG; portability proof on SCB Spark Streaming; monitoring and runbooks | Pilot KPIs (response rate, latency); portability run passes | Go/no-go for second market |
| **R2 — Zerobus eval** | parallel | Feasibility against Solace client model and source-team appetite | Written recommendation | Dhas |

---

## 8. Open decisions and risks

### 8.1 Decisions for SCB

1. **ODS persistence model:** Databricks as streaming processor with Gold flowed back on-prem (Dhas's current lean, since the latency-sensitive path gains little from an on-prem hop first) vs on-prem-first with Databricks copying from the ODS. The architecture above supports either; it changes where Silver/Gold are considered authoritative.
2. **Messaging bridge:** Solace→Kafka vs Solace→Event Hubs, and which WRB topics are in scope first.
3. **Pattern approval:** Databricks sourcing from business-application databases (SpringWatch/ODS).
4. **Zerobus:** evaluate, pilot or park.

### 8.2 Risks

| Risk | Impact | Mitigation |
|---|---|---|
| Kafka rollout does not cover WRB topics in time | Ingest delayed | Event Hubs bridge as interim; identical Spark code |
| Tokenization service latency on the hot path | Erodes < 5 min target | Batch tokenization per micro-batch; cache token mappings in Silver dimensions |
| JDBC to on-prem Postgres blocked | No flow-back | Emit-back via Kafka as primary integration; Postgres consumes from topic |
| Tool-calling egress unresolved | AI brief limited to UC data | Ground brief only in UC/Lakebase for Release 1; APIs in Release 1.x |
| Portability drifts as DLT features are adopted | China path breaks | Portable core + CI job that runs core on OSS Spark |
| Alert fatigue / wrong thresholds | RM adoption fails | Rules table owned by WRB; team-lead view tracks created vs suppressed |

---

## 9. Action items carried from 21 Oct

**Databricks (Sid)**
- Two-ended setup: Kafka/Solace topics → UC, and Gold → on-prem Postgres + emit-back to SCB topics.
- Demo account and tutorials, including artifact extraction to run on SCB Spark Streaming.
- Share aggregation and lineage code behind the gold signal table.
- Bring platform networking expert; continue tool-calling blocker thread.
- Tokenization / PII element in the design (Section 6.1 of this document).

**SCB**
- Dhas / Habeeb: cloud platform network contact for joint connectivity session.
- Habeeb: pattern approval for Databricks sourcing from ODS / business-app databases.
- Dhas: Zerobus feasibility vs Solace client model.
- Habeeb / Dhas: ODS persistence model decision.

---

*Next step: review this draft with Habeeb and Dhas, confirm the bridge option and persistence model, then convert Phases 0–1 into a dated plan with named engineers.*
