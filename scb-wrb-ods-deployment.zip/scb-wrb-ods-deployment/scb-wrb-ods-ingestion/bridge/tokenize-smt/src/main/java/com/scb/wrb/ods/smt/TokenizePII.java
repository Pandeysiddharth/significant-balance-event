package com.scb.wrb.ods.smt;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.kafka.common.config.AbstractConfig;
import org.apache.kafka.common.config.ConfigDef;
import org.apache.kafka.connect.connector.ConnectRecord;
import org.apache.kafka.connect.errors.DataException;
import org.apache.kafka.connect.errors.RetriableException;
import org.apache.kafka.connect.transforms.Transformation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Kafka Connect SMT: tokenizes PII fields in a JSON payload by calling SCB's
 * enterprise tokenization service, so the record published to the Azure-mirrored
 * topic never contains clear-text PII.
 *
 * Design constraints
 *  - Tokenization MUST be deterministic (same input -> same token). The Gold layer
 *    (30-day baseline, suppression counters, customer-dimension joins) relies on the
 *    token being a stable key. The scheme is passed to the service; the service
 *    enforces determinism.
 *  - Batch call per record (all fields in one request) + LRU cache keeps added
 *    latency low. Cache holds clear->token pairs in bridge memory only, on-prem.
 *  - On service failure: RetriableException so the connector retries; after
 *    retries the record goes to the connector DLQ, which MUST be an on-prem-only
 *    topic (it carries clear text) and MUST NOT be in the MirrorMaker allow-list.
 *  - Required fields missing from a payload => DataException (fail the record).
 *    Landing a payload with an untokenized customer id is never acceptable.
 *
 * Only the Value variant is used; keys are correlation ids, not PII.
 */
public abstract class TokenizePII<R extends ConnectRecord<R>> implements Transformation<R> {

    private static final Logger LOG = LoggerFactory.getLogger(TokenizePII.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    public static final String SERVICE_URL = "service.url";
    public static final String SERVICE_AUTH_HEADER = "service.auth.header";
    public static final String SERVICE_TIMEOUT_MS = "service.timeout.ms";
    public static final String SERVICE_SCHEME = "service.scheme";
    public static final String FIELDS = "fields";
    public static final String FIELDS_REQUIRED = "fields.required";
    public static final String CACHE_SIZE = "cache.size";
    public static final String FAIL_ON_ERROR = "fail.on.error";

    public static final ConfigDef CONFIG_DEF = new ConfigDef()
        .define(SERVICE_URL, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH,
            "Batch tokenization endpoint")
        .define(SERVICE_AUTH_HEADER, ConfigDef.Type.PASSWORD, "", ConfigDef.Importance.HIGH,
            "Full Authorization header value")
        .define(SERVICE_TIMEOUT_MS, ConfigDef.Type.INT, 800, ConfigDef.Importance.MEDIUM,
            "HTTP timeout per call")
        .define(SERVICE_SCHEME, ConfigDef.Type.STRING, ConfigDef.Importance.HIGH,
            "Tokenization scheme name; must be a deterministic scheme")
        .define(FIELDS, ConfigDef.Type.LIST, ConfigDef.Importance.HIGH,
            "Dot-path JSON fields to tokenize")
        .define(FIELDS_REQUIRED, ConfigDef.Type.LIST, Collections.emptyList(), ConfigDef.Importance.HIGH,
            "Subset of fields that must be present and tokenized, else the record fails")
        .define(CACHE_SIZE, ConfigDef.Type.INT, 100_000, ConfigDef.Importance.LOW,
            "LRU cache entries (clear->token)")
        .define(FAIL_ON_ERROR, ConfigDef.Type.BOOLEAN, true, ConfigDef.Importance.HIGH,
            "If false, service errors pass the record through UNTOKENIZED. Only for isolated testing.");

    private String serviceUrl;
    private String authHeader;
    private Duration timeout;
    private String scheme;
    private List<String> fields;
    private Set<String> requiredFields;
    private boolean failOnError;
    private HttpClient http;
    private Map<String, String> cache;

    @Override
    public void configure(Map<String, ?> configs) {
        AbstractConfig cfg = new AbstractConfig(CONFIG_DEF, configs);
        serviceUrl = cfg.getString(SERVICE_URL);
        authHeader = cfg.getPassword(SERVICE_AUTH_HEADER).value();
        timeout = Duration.ofMillis(cfg.getInt(SERVICE_TIMEOUT_MS));
        scheme = cfg.getString(SERVICE_SCHEME);
        fields = cfg.getList(FIELDS);
        requiredFields = new HashSet<>(cfg.getList(FIELDS_REQUIRED));
        failOnError = cfg.getBoolean(FAIL_ON_ERROR);
        if (!failOnError) {
            LOG.warn("fail.on.error=false: records may be published UNTOKENIZED. Never use in production.");
        }
        final int maxEntries = cfg.getInt(CACHE_SIZE);
        cache = Collections.synchronizedMap(new LinkedHashMap<String, String>(1024, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<String, String> eldest) {
                return size() > maxEntries;
            }
        });
        http = HttpClient.newBuilder().connectTimeout(timeout).build();
    }

    @Override
    public R apply(R record) {
        Object value = operatingValue(record);
        if (value == null) {
            return record;
        }
        byte[] bytes;
        if (value instanceof byte[]) {
            bytes = (byte[]) value;
        } else if (value instanceof String) {
            bytes = ((String) value).getBytes(StandardCharsets.UTF_8);
        } else {
            throw new DataException("TokenizePII expects bytes or String payload, got " + value.getClass());
        }

        final ObjectNode root;
        try {
            JsonNode parsed = MAPPER.readTree(bytes);
            if (!parsed.isObject()) {
                throw new DataException("Payload is not a JSON object");
            }
            root = (ObjectNode) parsed;
        } catch (IOException e) {
            throw new DataException("Payload is not valid JSON", e);
        }

        // Collect clear values that need tokens. A path segment ending in "[]" fans out over an
        // array (e.g. accounts[].number), so one configured path may yield many target slots.
        List<Slot> slots = new ArrayList<>();
        for (String path : fields) {
            List<Slot> found = resolveSlots(root, path);
            if (found.isEmpty()) {
                if (requiredFields.contains(path)) {
                    throw new DataException("Required PII field missing: " + path);
                }
                continue;
            }
            slots.addAll(found);
        }

        Set<String> clears = new HashSet<>();
        for (Slot s : slots) {
            clears.add(s.clear);
        }
        Map<String, String> tokenByClear = resolveTokens(clears);

        for (Slot s : slots) {
            String token = tokenByClear.get(s.clear);
            if (token == null) {
                if (failOnError) {
                    throw new DataException("No token returned for field " + s.path);
                }
                continue;
            }
            s.parent.put(s.field, token);
        }

        root.put("_tokenization_scheme", scheme);

        byte[] out;
        try {
            out = MAPPER.writeValueAsBytes(root);
        } catch (IOException e) {
            throw new DataException("Failed to serialise tokenized payload", e);
        }
        Object newValue = (value instanceof String) ? new String(out, StandardCharsets.UTF_8) : out;
        return newRecord(record, newValue);
    }

    /** Resolve tokens for a set of clear values, using the cache and one batch call for misses. */
    private Map<String, String> resolveTokens(Set<String> clears) {
        Map<String, String> result = new HashMap<>();
        List<String> misses = new ArrayList<>();
        for (String c : clears) {
            String t = cache.get(c);
            if (t != null) {
                result.put(c, t);
            } else {
                misses.add(c);
            }
        }
        if (misses.isEmpty()) {
            return result;
        }
        try {
            ObjectNode body = MAPPER.createObjectNode();
            body.put("scheme", scheme);
            body.putPOJO("values", misses);
            HttpRequest req = HttpRequest.newBuilder(URI.create(serviceUrl))
                .timeout(timeout)
                .header("Content-Type", "application/json")
                .header("Authorization", authHeader)
                .POST(HttpRequest.BodyPublishers.ofByteArray(MAPPER.writeValueAsBytes(body)))
                .build();
            HttpResponse<byte[]> resp = http.send(req, HttpResponse.BodyHandlers.ofByteArray());
            if (resp.statusCode() >= 500 || resp.statusCode() == 429) {
                throw new RetriableException("Tokenization service " + resp.statusCode());
            }
            if (resp.statusCode() != 200) {
                throw new DataException("Tokenization service rejected request: " + resp.statusCode());
            }
            // Expected response: {"tokens": {"<clear>": "<token>", ...}}
            JsonNode tokens = MAPPER.readTree(resp.body()).path("tokens");
            for (String c : misses) {
                JsonNode t = tokens.get(c);
                if (t != null && !t.isNull()) {
                    cache.put(c, t.asText());
                    result.put(c, t.asText());
                }
            }
            return result;
        } catch (IOException e) {
            throw new RetriableException("Tokenization service unreachable", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RetriableException("Interrupted calling tokenization service", e);
        }
    }

    /** A concrete JSON field holding a clear value that must be replaced. */
    private static final class Slot {
        final String path;
        final ObjectNode parent;
        final String field;
        final String clear;

        Slot(String path, ObjectNode parent, String field, String clear) {
            this.path = path;
            this.parent = parent;
            this.field = field;
            this.clear = clear;
        }
    }

    /** Resolve a dot path, fanning out over "name[]" array segments, to the slots that hold non-empty values. */
    private static List<Slot> resolveSlots(ObjectNode root, String dotPath) {
        String[] parts = dotPath.split("\\.");
        List<ObjectNode> parents = new ArrayList<>();
        parents.add(root);
        for (int i = 0; i < parts.length - 1; i++) {
            String p = parts[i];
            boolean fanOut = p.endsWith("[]");
            String name = fanOut ? p.substring(0, p.length() - 2) : p;
            List<ObjectNode> next = new ArrayList<>();
            for (ObjectNode parent : parents) {
                JsonNode child = parent.get(name);
                if (child == null || child.isNull()) {
                    continue;
                }
                if (fanOut) {
                    if (child.isArray()) {
                        for (JsonNode el : child) {
                            if (el.isObject()) {
                                next.add((ObjectNode) el);
                            }
                        }
                    }
                } else if (child.isObject()) {
                    next.add((ObjectNode) child);
                }
            }
            parents = next;
        }
        String leaf = parts[parts.length - 1];
        List<Slot> slots = new ArrayList<>();
        for (ObjectNode parent : parents) {
            JsonNode v = parent.get(leaf);
            if (v != null && !v.isNull() && !v.asText().isEmpty()) {
                slots.add(new Slot(dotPath, parent, leaf, v.asText()));
            }
        }
        return slots;
    }

    @Override
    public ConfigDef config() {
        return CONFIG_DEF;
    }

    @Override
    public void close() {
        cache.clear();
    }

    protected abstract Object operatingValue(R record);

    protected abstract R newRecord(R record, Object updatedValue);

    public static final class Value<R extends ConnectRecord<R>> extends TokenizePII<R> {
        @Override
        protected Object operatingValue(R record) {
            return record.value();
        }

        @Override
        protected R newRecord(R record, Object updatedValue) {
            return record.newRecord(record.topic(), record.kafkaPartition(), record.keySchema(), record.key(),
                record.valueSchema(), updatedValue, record.timestamp(), record.headers());
        }
    }
}
