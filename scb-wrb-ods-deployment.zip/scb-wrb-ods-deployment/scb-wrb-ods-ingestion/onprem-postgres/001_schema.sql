-- WRB ODS serving schema on the on-prem Postgres (SpringWatch ODS). Run as the ODS owner.
-- Receives TOKENIZED signals from Databricks. Clear customer attributes are joined in here
-- (002_token_resolution.sql); Databricks never sees them.

CREATE SCHEMA IF NOT EXISTS wrb_ods;

-- Roles -------------------------------------------------------------------------------------
-- wrb_ods_sync   : the Databricks JDBC principal. Writes staging + rm_signals + watermark only.
-- wrb_ods_api    : the SpringWatch API service. Reads resolved views, writes outcomes outbox.
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'wrb_ods_sync') THEN CREATE ROLE wrb_ods_sync LOGIN; END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'wrb_ods_api')  THEN CREATE ROLE wrb_ods_api  LOGIN; END IF;
END $$;

-- Target: mirror of gold.rm_signals ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS wrb_ods.rm_signals (
  signal_id            VARCHAR(32)    PRIMARY KEY,
  event_id             TEXT           NOT NULL,
  customer_token       TEXT           NOT NULL,
  account_token        TEXT,
  rm_id                TEXT,
  team_id              TEXT,
  segment              TEXT,
  signal_type          TEXT           NOT NULL,
  priority             TEXT,
  fraud_flag           BOOLEAN        NOT NULL DEFAULT FALSE,
  amount_usd           NUMERIC(20,2),
  currency             CHAR(3),
  amount               NUMERIC(20,2),
  multiple_of_norm     NUMERIC(12,2),
  trigger_rule         TEXT,
  status               TEXT           NOT NULL,
  suppression_reason   TEXT,
  preferred_language   TEXT,
  open_complaints      INTEGER,
  contacts_last_48h    INTEGER,
  event_ts             TIMESTAMPTZ,
  created_ts           TIMESTAMPTZ    NOT NULL,
  expires_at           TIMESTAMPTZ    NOT NULL,
  rules_snapshot       JSONB,
  baseline_as_of_ts    TIMESTAMPTZ,
  bronze_source_topic  TEXT,
  bronze_partition     INTEGER,
  bronze_offset        BIGINT,
  kafka_ts             TIMESTAMPTZ,
  signal_latency_ms    BIGINT,
  -- sync bookkeeping
  commit_version       BIGINT         NOT NULL,     -- Delta commit version of the change applied
  synced_at            TIMESTAMPTZ    NOT NULL DEFAULT now(),
  CONSTRAINT rm_signals_status_chk CHECK (status IN ('CREATED','SUPPRESSED','ACTIONED','EXPIRED'))
);
CREATE INDEX IF NOT EXISTS rm_signals_active_idx   ON wrb_ods.rm_signals (rm_id, expires_at) WHERE status = 'CREATED';
CREATE INDEX IF NOT EXISTS rm_signals_customer_idx ON wrb_ods.rm_signals (customer_token, created_ts DESC);
CREATE INDEX IF NOT EXISTS rm_signals_team_day_idx ON wrb_ods.rm_signals (team_id, (created_ts::date));
COMMENT ON TABLE wrb_ods.rm_signals IS 'Mirror of Databricks gold.rm_signals. Tokenized. Upserted by Databricks CDF sink; last Delta commit wins.';

-- Staging: Spark JDBC overwrites this per micro-batch, then the upsert runs in one transaction.
-- UNLOGGED: no WAL cost, contents are disposable (the Delta checkpoint is the source of truth).
CREATE UNLOGGED TABLE IF NOT EXISTS wrb_ods.rm_signals_staging (LIKE wrb_ods.rm_signals INCLUDING DEFAULTS);
ALTER TABLE wrb_ods.rm_signals_staging ALTER COLUMN rules_snapshot TYPE TEXT;   -- Spark writes JSON text; cast on upsert
ALTER TABLE wrb_ods.rm_signals_staging DROP CONSTRAINT IF EXISTS rm_signals_staging_pkey;

-- Watermark: what has been applied, for lag monitoring and reconciliation
CREATE TABLE IF NOT EXISTS wrb_ods.sync_watermark (
  table_name            TEXT PRIMARY KEY,
  last_commit_version   BIGINT NOT NULL,
  last_commit_ts        TIMESTAMPTZ,
  last_batch_id         BIGINT,
  rows_upserted         BIGINT,
  synced_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Reverse path: RM outcomes captured on-prem (SpringWatch / CRM) flow back to Databricks.
-- The API writes here; an SCB publisher drains it to the Solace topic wrb/ods/signal_outcomes
-- (bridge tokenizes notes) -> Databricks Bronze -> gold.signal_outcomes. Closes the
-- "contacted 3x in 48h" suppression loop.
CREATE TABLE IF NOT EXISTS wrb_ods.signal_outcomes_outbox (
  outcome_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  signal_id        VARCHAR(32) NOT NULL REFERENCES wrb_ods.rm_signals (signal_id),
  customer_token   TEXT NOT NULL,
  rm_id            TEXT,
  outcome          TEXT NOT NULL CHECK (outcome IN ('CONTACTED_PITCHED','CONTACTED_VERIFIED','CONTACTED_NO_ANSWER','ESCALATED_FRAUD','DISMISSED')),
  product_pitched  TEXT,
  notes            TEXT,                 -- CLEAR text here; tokenized by the bridge before leaving on-prem
  contacted_ts     TIMESTAMPTZ NOT NULL DEFAULT now(),
  recorded_ts      TIMESTAMPTZ NOT NULL DEFAULT now(),
  published_ts     TIMESTAMPTZ            -- set by the outbox publisher
);
CREATE INDEX IF NOT EXISTS outcomes_outbox_unpublished_idx ON wrb_ods.signal_outcomes_outbox (recorded_ts) WHERE published_ts IS NULL;

-- Grants -------------------------------------------------------------------------------------
GRANT USAGE ON SCHEMA wrb_ods TO wrb_ods_sync, wrb_ods_api;
GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE ON wrb_ods.rm_signals_staging TO wrb_ods_sync;
GRANT SELECT, INSERT, UPDATE ON wrb_ods.rm_signals, wrb_ods.sync_watermark TO wrb_ods_sync;
GRANT SELECT ON wrb_ods.rm_signals TO wrb_ods_api;
GRANT SELECT, INSERT ON wrb_ods.signal_outcomes_outbox TO wrb_ods_api;
