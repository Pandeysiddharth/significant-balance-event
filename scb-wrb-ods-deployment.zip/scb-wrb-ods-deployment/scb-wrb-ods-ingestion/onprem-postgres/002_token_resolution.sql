-- Token resolution ON-PREM, by join. Databricks has no detokenization capability.
--
-- SCB tokenizes its own customer master ONCE with the same deterministic scheme the bridge uses
-- (WRB_CUSTOMER_DETERMINISTIC_FPE), storing the token next to the clear key. From then on a
-- token arriving from Databricks is just a surrogate key: no per-row tokenization-service call
-- on the serving path.
--
-- Maintained by an SCB job: whenever customer_master changes, re-tokenize the changed rows.

CREATE TABLE IF NOT EXISTS wrb_ods.customer_token_map (
  customer_token   TEXT PRIMARY KEY,
  customer_id      TEXT NOT NULL UNIQUE,        -- clear CIF / customer id, FK to the ODS customer master
  tokenized_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  scheme           TEXT NOT NULL DEFAULT 'WRB_CUSTOMER_DETERMINISTIC_FPE'
);
CREATE TABLE IF NOT EXISTS wrb_ods.account_token_map (
  account_token    TEXT PRIMARY KEY,
  account_number   TEXT NOT NULL UNIQUE,
  tokenized_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  scheme           TEXT NOT NULL DEFAULT 'WRB_CUSTOMER_DETERMINISTIC_FPE'
);
-- Only the mapping-maintenance job and the API role touch these; the Databricks sync role cannot read them.
REVOKE ALL ON wrb_ods.customer_token_map, wrb_ods.account_token_map FROM wrb_ods_sync;
GRANT SELECT ON wrb_ods.customer_token_map, wrb_ods.account_token_map TO wrb_ods_api;

-- Resolved view for the RM API. Assumes the existing ODS customer master is reachable as
-- ods.customer_master (customer_id, full_name, mobile, email, ...). Adjust to the real schema.
CREATE OR REPLACE VIEW wrb_ods.v_rm_signals_active_resolved AS
SELECT s.signal_id, s.signal_type, s.priority, s.fraud_flag, s.status,
       s.amount, s.currency, s.amount_usd, s.multiple_of_norm, s.trigger_rule,
       s.event_ts, s.created_ts, s.expires_at, s.preferred_language, s.open_complaints,
       s.rm_id, s.team_id, s.segment,
       m.customer_id,                       -- clear key, resolved on-prem
       cm.full_name, cm.mobile, cm.email,   -- clear attributes from the ODS master
       a.account_number,
       s.signal_latency_ms
FROM wrb_ods.rm_signals s
JOIN wrb_ods.customer_token_map m  ON m.customer_token = s.customer_token
JOIN ods.customer_master cm        ON cm.customer_id   = m.customer_id
LEFT JOIN wrb_ods.account_token_map a ON a.account_token = s.account_token
WHERE s.status = 'CREATED' AND s.expires_at > now();
GRANT SELECT ON wrb_ods.v_rm_signals_active_resolved TO wrb_ods_api;

-- Unresolved tokens are an operational signal: the master map is behind the event stream
-- (new customer) or the scheme has drifted. Alert on this.
CREATE OR REPLACE VIEW wrb_ods.v_unresolved_signal_tokens AS
SELECT s.signal_id, s.customer_token, s.created_ts
FROM wrb_ods.rm_signals s
LEFT JOIN wrb_ods.customer_token_map m ON m.customer_token = s.customer_token
WHERE m.customer_token IS NULL AND s.created_ts > now() - INTERVAL '1 day';
GRANT SELECT ON wrb_ods.v_unresolved_signal_tokens TO wrb_ods_api;
