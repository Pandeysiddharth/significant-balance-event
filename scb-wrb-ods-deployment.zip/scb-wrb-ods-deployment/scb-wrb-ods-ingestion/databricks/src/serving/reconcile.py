"""
Daily reconciliation: gold.rm_signals vs on-prem wrb_ods.rm_signals.

Compares, per created date over the last N days: row count, count by status, and a checksum over
(signal_id, status, expires_at). Mismatches are written to <market>_ops.postgres_sink_reconciliation
and logged; the alert on that table pages platform ops. Fix is to re-run postgres_sink.py with
--starting-version at the first mismatching commit (idempotent upsert makes this safe).

Usage: reconcile.py --market hk [--days 3]
"""
from __future__ import annotations

import argparse
import logging
import os
import sys

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from postgres_sink import pg_config  # noqa: E402

log = logging.getLogger("reconcile")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")


def run(market: str, days: int) -> None:
    spark = SparkSession.builder.getOrCreate()
    from pyspark.dbutils import DBUtils  # type: ignore
    pg = pg_config(DBUtils(spark))

    def summarise(df):
        return (df.filter(F.col("created_ts") >= F.current_date() - days)
                  .withColumn("d", F.to_date("created_ts"))
                  .groupBy("d", "status")
                  .agg(F.count("*").alias("n"),
                       F.sum(F.conv(F.substring(F.sha2(F.concat_ws("|", "signal_id", "status",
                                                                     F.col("expires_at").cast("string")), 256), 1, 12), 16, 10)
                             .cast("decimal(38,0)")).alias("checksum")))

    gold = summarise(spark.table(f"wrb_ods.{market}_gold.rm_signals"))
    pg_query = f"(SELECT signal_id, status, expires_at, created_ts FROM wrb_ods.rm_signals WHERE created_ts >= now() - interval '{days} days') t"
    onprem = summarise(spark.read.format("jdbc").option("url", pg["url"]).option("user", pg["user"])
                       .option("password", pg["password"]).option("driver", pg["driver"])
                       .option("dbtable", pg_query).load())

    cmp = (gold.alias("g").join(onprem.alias("p"), ["d", "status"], "full")
           .select("d", "status",
                   F.col("g.n").alias("gold_n"), F.col("p.n").alias("pg_n"),
                   F.col("g.checksum").alias("gold_checksum"), F.col("p.checksum").alias("pg_checksum"))
           .withColumn("match", (F.col("gold_n") == F.col("pg_n")) & (F.col("gold_checksum") == F.col("pg_checksum")))
           .withColumn("checked_ts", F.current_timestamp()))

    cmp.write.format("delta").mode("append").saveAsTable(f"wrb_ods.{market}_ops.postgres_sink_reconciliation")
    bad = cmp.filter(~F.coalesce("match", F.lit(False))).collect()
    if bad:
        log.error("RECONCILIATION MISMATCH market=%s rows=%s", market, [(r.d, r.status, r.gold_n, r.pg_n) for r in bad])
    else:
        log.info("reconciliation clean market=%s days=%s", market, days)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--market", required=True)
    ap.add_argument("--days", type=int, default=3)
    a = ap.parse_args()
    run(a.market, a.days)
