"""
Reverse path: RM outcomes captured on-prem -> gold.signal_outcomes.

On-prem: SpringWatch API writes wrb_ods.signal_outcomes_outbox -> SCB outbox publisher -> Solace
topic -> bridge (tokenizes `notes` and customer id) -> wrb.ods.<market>.signal_outcomes.tokenized
-> MM2 -> Bronze (bronze_ingest.py, generic) -> this job -> gold.signal_outcomes (MERGE on outcome_id).

Expected tokenized payload:
  { "outcome_id", "signal_id", "customer": {"id"}, "rm_id", "outcome", "product_pitched",
    "notes", "contacted_ts", "recorded_ts" }

Usage: outcomes_ingest.py --market hk [--trigger-mode continuous|available_now]
"""
from __future__ import annotations

import argparse
import logging

from delta.tables import DeltaTable
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

log = logging.getLogger("outcomes_ingest")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")

SCHEMA = T.StructType([
    T.StructField("outcome_id", T.StringType()),
    T.StructField("signal_id", T.StringType()),
    T.StructField("customer", T.StructType([T.StructField("id", T.StringType())])),
    T.StructField("rm_id", T.StringType()),
    T.StructField("outcome", T.StringType()),
    T.StructField("product_pitched", T.StringType()),
    T.StructField("notes", T.StringType()),
    T.StructField("contacted_ts", T.StringType()),
    T.StructField("recorded_ts", T.StringType()),
])
VALID = ("CONTACTED_PITCHED", "CONTACTED_VERIFIED", "CONTACTED_NO_ANSWER", "ESCALATED_FRAUD", "DISMISSED")


def parse(bronze: DataFrame) -> DataFrame:
    e = F.from_json("payload", SCHEMA).alias("e")
    return bronze.select(e).select(
        F.col("e.outcome_id").alias("outcome_id"),
        F.col("e.signal_id").alias("signal_id"),
        F.col("e.customer.id").alias("customer_token"),
        F.col("e.rm_id").alias("rm_id"),
        F.upper("e.outcome").alias("outcome"),
        F.col("e.product_pitched").alias("product_pitched"),
        F.col("e.notes").alias("notes_token"),
        F.to_timestamp("e.contacted_ts").alias("contacted_ts"),
        F.to_timestamp("e.recorded_ts").alias("recorded_ts"),
    ).filter(F.col("outcome_id").isNotNull() & F.col("signal_id").isNotNull() & F.col("outcome").isin(*VALID))


def make_batch_writer(spark: SparkSession, market: str):
    target = f"wrb_ods.{market}_gold.signal_outcomes"

    def write_batch(df: DataFrame, batch_id: int) -> None:
        rows = df.dropDuplicates(["outcome_id"])
        (DeltaTable.forName(spark, target).alias("t")
         .merge(rows.alias("s"), "t.outcome_id = s.outcome_id")
         .whenNotMatchedInsertAll()
         .execute())
        log.info("batch=%s outcomes merged", batch_id)

    return write_batch


def run(market: str, trigger_mode: str) -> None:
    spark = SparkSession.builder.getOrCreate()
    src = spark.readStream.format("delta").table(f"wrb_ods.{market}_bronze.signal_outcome_events")
    writer = (parse(src).writeStream.foreachBatch(make_batch_writer(spark, market))
              .option("checkpointLocation", f"/Volumes/wrb_ods/{market}_ops/checkpoints/serving/outcomes_ingest")
              .queryName(f"serving_{market}_outcomes_ingest"))
    writer = writer.trigger(availableNow=True) if trigger_mode == "available_now" \
        else writer.trigger(processingTime="5 seconds")
    writer.start().awaitTermination()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--market", required=True)
    ap.add_argument("--trigger-mode", default="continuous", choices=["continuous", "available_now"])
    a = ap.parse_args()
    run(a.market, a.trigger_mode)
