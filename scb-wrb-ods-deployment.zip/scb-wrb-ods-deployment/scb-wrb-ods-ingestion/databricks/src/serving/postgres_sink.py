"""
Serving: gold.rm_signals -> on-prem Postgres (wrb_ods.rm_signals), driven by Delta Change Data Feed.

Per micro-batch:
  1. read CDF rows (insert / update_postimage only), collapse to the latest change per signal_id
  2. Spark JDBC overwrite of wrb_ods.rm_signals_staging (truncate, not drop: keeps grants/types)
  3. one JDBC transaction: upsert staging -> rm_signals (newer commit wins), update sync_watermark
  4. audit row in <market>_ops.postgres_sink_audit

Idempotency: the Delta checkpoint replays a failed batch; the upsert's commit_version guard makes
the replay a no-op. Throwing from write_batch on JDBC failure is therefore the correct behaviour:
the stream retries, and the continuous job restarts it if retries are exhausted.

Connectivity: Databricks -> on-prem Postgres over the private path agreed in the joint platform
session (NCC private endpoint / ExpressRoute). Credentials in secret scope wrb-ods (pg_*).

Usage: postgres_sink.py --market hk [--trigger-mode continuous|available_now] [--starting-version N]
"""
from __future__ import annotations

import argparse
import logging
import os
import sys

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sink_utils import (  # noqa: E402
    CDF_APPLY_TYPES, JSONB_COLUMNS, SIGNAL_COLUMNS, build_upsert_sql, build_watermark_sql, jdbc_url,
)

log = logging.getLogger("postgres_sink")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")

PG_SCHEMA = "wrb_ods"
PG_TARGET = "rm_signals"
PG_STAGING = "rm_signals_staging"


def _secret(dbutils, key: str) -> str:
    return dbutils.secrets.get(scope="wrb-ods", key=key)


def pg_config(dbutils) -> dict:
    return {
        "url": jdbc_url(_secret(dbutils, "pg_host"), int(_secret(dbutils, "pg_port")), _secret(dbutils, "pg_database"),
                        extra={"sslrootcert": "/Volumes/wrb_ods/shared_ops/certs/scb-root-ca.pem"}),
        "user": _secret(dbutils, "pg_user"),
        "password": _secret(dbutils, "pg_password"),
        "driver": "org.postgresql.Driver",
    }


def collapse_changes(cdf: DataFrame) -> DataFrame:
    """Latest applicable change per signal_id within the batch."""
    applicable = cdf.filter(F.col("_change_type").isin(*CDF_APPLY_TYPES))
    w = Window.partitionBy("signal_id").orderBy(F.col("_commit_version").desc(), F.col("_commit_timestamp").desc())
    latest = applicable.withColumn("rn", F.row_number().over(w)).filter("rn = 1").drop("rn")
    cols = [F.to_json(F.col(c)).alias(c) if c in JSONB_COLUMNS else F.col(c) for c in SIGNAL_COLUMNS]
    return latest.select(*cols, F.col("_commit_version").alias("commit_version"),
                         F.col("_commit_timestamp").alias("commit_ts"))


def make_batch_writer(spark: SparkSession, market: str, pg: dict):
    audit_tbl = f"wrb_ods.{market}_ops.postgres_sink_audit"
    upsert_sql = build_upsert_sql(PG_SCHEMA, PG_TARGET, PG_STAGING)
    watermark_sql = build_watermark_sql(PG_SCHEMA, f"{market}.{PG_TARGET}")
    jvm = spark._sc._gateway.jvm  # JDBC via the driver JVM; PostgreSQL driver ships with DBR

    def write_batch(cdf_batch: DataFrame, batch_id: int) -> None:
        rows = collapse_changes(cdf_batch).persist()
        try:
            n = rows.count()
            if n == 0:
                return
            stats = rows.agg(F.max("commit_version").alias("v"), F.max("commit_ts").alias("ts")).collect()[0]

            # 1. stage (Spark JDBC, parallel writers)
            (rows.drop("commit_ts").write.format("jdbc")
                 .option("url", pg["url"]).option("user", pg["user"]).option("password", pg["password"])
                 .option("driver", pg["driver"])
                 .option("dbtable", f"{PG_SCHEMA}.{PG_STAGING}")
                 .option("truncate", "true").option("batchsize", "5000").option("isolationLevel", "READ_COMMITTED")
                 .mode("overwrite").save())

            # 2. apply in one transaction
            conn = jvm.java.sql.DriverManager.getConnection(pg["url"], pg["user"], pg["password"])
            try:
                conn.setAutoCommit(False)
                st = conn.createStatement()
                upserted = st.executeUpdate(upsert_sql)
                st.close()
                ps = conn.prepareStatement(watermark_sql)
                ps.setLong(1, int(stats["v"]))
                ps.setTimestamp(2, jvm.java.sql.Timestamp(int(stats["ts"].timestamp() * 1000)))
                ps.setLong(3, int(batch_id))
                ps.setLong(4, int(upserted))
                ps.executeUpdate()
                ps.close()
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()

            # 3. audit
            spark.createDataFrame(
                [(int(batch_id), n, int(upserted), int(stats["v"]), stats["ts"])],
                "batch_id bigint, rows_in bigint, rows_upserted bigint, max_commit_version bigint, max_commit_ts timestamp",
            ).withColumn("sink_ts", F.current_timestamp()) \
             .withColumn("sink_lag_ms", (F.unix_millis("sink_ts") - F.unix_millis("max_commit_ts")).cast("bigint")) \
             .write.format("delta").mode("append").saveAsTable(audit_tbl)
            log.info("batch=%s staged=%s upserted=%s commit_version=%s", batch_id, n, upserted, stats["v"])
        finally:
            rows.unpersist()

    return write_batch


def run(market: str, trigger_mode: str, starting_version: int | None) -> None:
    spark = SparkSession.builder.getOrCreate()
    from pyspark.dbutils import DBUtils  # type: ignore
    pg = pg_config(DBUtils(spark))

    reader = spark.readStream.format("delta").option("readChangeFeed", "true").option("maxFilesPerTrigger", 100)
    if starting_version is not None:
        reader = reader.option("startingVersion", starting_version)
    src = reader.table(f"wrb_ods.{market}_gold.rm_signals")

    writer = (src.writeStream.foreachBatch(make_batch_writer(spark, market, pg))
              .option("checkpointLocation", f"/Volumes/wrb_ods/{market}_ops/checkpoints/serving/postgres_sink")
              .queryName(f"serving_{market}_postgres_sink"))
    writer = writer.trigger(availableNow=True) if trigger_mode == "available_now" \
        else writer.trigger(processingTime="5 seconds")
    writer.start().awaitTermination()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--market", required=True)
    ap.add_argument("--trigger-mode", default="continuous", choices=["continuous", "available_now"])
    ap.add_argument("--starting-version", type=int, default=None, help="Delta version to start CDF from (backfill)")
    a = ap.parse_args()
    run(a.market, a.trigger_mode, a.starting_version)
