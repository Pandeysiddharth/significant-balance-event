"""
Serving: emit signal lifecycle events (signal.created / suppressed / expired / actioned) from
gold.rm_signals CDF to the Azure Kafka topic wrb.ods.<market>.signal_events. MirrorMaker 2 replicates
that one topic azure -> on-prem so Fusion, SpringWatch and CRM subscribe on-prem without calling
Databricks. Payload is tokenized (it is the Gold row); consumers resolve tokens on-prem by join.

Separate checkpoint from postgres_sink so one sink's outage does not stall the other.

Usage: kafka_emit.py --market hk [--trigger-mode continuous|available_now]
"""
from __future__ import annotations

import argparse
import logging
import os
import sys

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sink_utils import event_type_for  # noqa: E402

log = logging.getLogger("kafka_emit")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")

EVENT_FIELDS = [
    "signal_id", "customer_token", "account_token", "rm_id", "team_id", "signal_type", "priority",
    "fraud_flag", "amount_usd", "currency", "amount", "multiple_of_norm", "trigger_rule", "status",
    "suppression_reason", "event_ts", "created_ts", "expires_at", "signal_latency_ms",
    "bronze_source_topic", "bronze_partition", "bronze_offset",
]

_event_type_udf = F.udf(event_type_for, T.StringType())


def to_events(cdf: DataFrame, market: str) -> DataFrame:
    """CDF rows -> Kafka (key, value, headers). Pre-images are used only to detect status transitions."""
    post = cdf.filter(F.col("_change_type").isin("insert", "update_postimage"))
    pre = (cdf.filter(F.col("_change_type") == "update_preimage")
              .select("signal_id", "_commit_version", F.col("status").alias("previous_status")))
    j = post.join(pre, ["signal_id", "_commit_version"], "left")
    j = j.withColumn("event_type", _event_type_udf("_change_type", "status", "previous_status")) \
         .filter(F.col("event_type").isNotNull())
    payload = F.to_json(F.struct(
        F.col("event_type"),
        F.lit("1").alias("schema_version"),
        F.lit(market).alias("market"),
        F.col("_commit_version").alias("source_commit_version"),
        F.current_timestamp().alias("emitted_ts"),
        *[F.col(c) for c in EVENT_FIELDS],
    ))
    return j.select(
        F.col("customer_token").alias("key"),
        payload.alias("value"),
        F.array(
            F.struct(F.lit("x-pii-tokenized").alias("key"), F.lit("true").cast("binary").alias("value")),
            F.struct(F.lit("event-type").alias("key"), F.col("event_type").cast("binary").alias("value")),
            F.struct(F.lit("source").alias("key"), F.lit("databricks.wrb_ods").cast("binary").alias("value")),
        ).alias("headers"),
    )


def kafka_sink_options(dbutils, market: str) -> dict:
    """Producer options; same OAuth principal and secret keys as the Bronze consumer."""
    import yaml
    k = yaml.safe_load(open(os.path.join(os.path.dirname(__file__), "..", "config", "topics.yml")))["defaults"]["kafka"]

    def sec(ref: str) -> str:
        scope, key = ref.split("/", 1)
        return dbutils.secrets.get(scope=scope, key=key)

    jaas = ("kafkashaded.org.apache.kafka.common.security.oauthbearer.OAuthBearerLoginModule required "
            f'clientId="{sec(k["oauth_client_id_secret"])}" clientSecret="{sec(k["oauth_client_secret_secret"])}" '
            f'scope="{sec(k["oauth_scope_secret"])}";')
    return {
        "kafka.bootstrap.servers": sec(k["bootstrap_servers_secret"]),
        "kafka.security.protocol": "SASL_SSL",
        "kafka.sasl.mechanism": "OAUTHBEARER",
        "kafka.sasl.jaas.config": jaas,
        "kafka.sasl.oauthbearer.token.endpoint.url": sec(k["oauth_token_endpoint_secret"]),
        "kafka.sasl.login.callback.handler.class":
            "kafkashaded.org.apache.kafka.common.security.oauthbearer.secured.OAuthBearerLoginCallbackHandler",
        "kafka.acks": "all",
        "kafka.enable.idempotence": "true",
        "kafka.compression.type": "zstd",
        "topic": f"wrb.ods.{market}.signal_events",
        "includeHeaders": "true",
    }


def run(market: str, trigger_mode: str) -> None:
    spark = SparkSession.builder.getOrCreate()
    from pyspark.dbutils import DBUtils  # type: ignore
    dbutils = DBUtils(spark)

    src = (spark.readStream.format("delta").option("readChangeFeed", "true")
           .table(f"wrb_ods.{market}_gold.rm_signals"))
    events = to_events(src, market)
    writer = (events.writeStream.format("kafka").options(**kafka_sink_options(dbutils, market))
              .option("checkpointLocation", f"/Volumes/wrb_ods/{market}_ops/checkpoints/serving/kafka_emit")
              .queryName(f"serving_{market}_kafka_emit"))
    writer = writer.trigger(availableNow=True) if trigger_mode == "available_now" \
        else writer.trigger(processingTime="2 seconds")
    writer.start().awaitTermination()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--market", required=True)
    ap.add_argument("--trigger-mode", default="continuous", choices=["continuous", "available_now"])
    a = ap.parse_args()
    run(a.market, a.trigger_mode)
