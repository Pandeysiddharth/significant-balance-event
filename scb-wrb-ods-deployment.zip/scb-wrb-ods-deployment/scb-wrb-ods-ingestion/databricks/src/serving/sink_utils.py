"""
Serving-layer helpers. Spark-free; tests in tests/test_sink_utils.py.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

# Columns copied gold.rm_signals -> wrb_ods.rm_signals (order matters for the staging write).
SIGNAL_COLUMNS: List[str] = [
    "signal_id", "event_id", "customer_token", "account_token", "rm_id", "team_id", "segment",
    "signal_type", "priority", "fraud_flag", "amount_usd", "currency", "amount",
    "multiple_of_norm", "trigger_rule", "status", "suppression_reason", "preferred_language",
    "open_complaints", "contacts_last_48h", "event_ts", "created_ts", "expires_at",
    "rules_snapshot", "baseline_as_of_ts", "bronze_source_topic", "bronze_partition",
    "bronze_offset", "kafka_ts", "signal_latency_ms",
]
SYNC_COLUMNS: List[str] = ["commit_version"]
JSONB_COLUMNS = {"rules_snapshot"}
KEY = "signal_id"

CDF_APPLY_TYPES = ("insert", "update_postimage")      # changes that produce a row to apply
CDF_IGNORE_TYPES = ("update_preimage", "delete")       # never applied to the serving store


def build_upsert_sql(schema: str, target: str, staging: str,
                     columns: Sequence[str] = SIGNAL_COLUMNS,
                     sync_columns: Sequence[str] = SYNC_COLUMNS,
                     key: str = KEY) -> str:
    """
    INSERT ... SELECT FROM staging ON CONFLICT (key) DO UPDATE ... WHERE newer commit.

    - JSONB columns are written to staging as text and cast here.
    - The WHERE on EXCLUDED.commit_version makes replays and out-of-order batches harmless:
      an older Delta commit can never overwrite a newer row.
    - If the same key appears twice in staging (should not, we collapse first) Postgres would
      error with 'ON CONFLICT DO UPDATE command cannot affect row a second time'; hence the
      DISTINCT ON in the SELECT as a belt-and-braces guard.
    """
    all_cols = list(columns) + list(sync_columns)
    select_exprs = [f"{c}::jsonb AS {c}" if c in JSONB_COLUMNS else c for c in all_cols]
    update_cols = [c for c in all_cols if c != key]
    set_clause = ",\n    ".join(f"{c} = EXCLUDED.{c}" for c in update_cols) + ",\n    synced_at = now()"
    return (
        f"INSERT INTO {schema}.{target} ({', '.join(all_cols)}, synced_at)\n"
        f"SELECT DISTINCT ON ({key}) {', '.join(select_exprs)}, now()\n"
        f"FROM {schema}.{staging}\n"
        f"ORDER BY {key}, commit_version DESC\n"
        f"ON CONFLICT ({key}) DO UPDATE SET\n    {set_clause}\n"
        f"WHERE EXCLUDED.commit_version > {schema}.{target}.commit_version;"
    )


def build_watermark_sql(schema: str, table_name: str) -> str:
    return (
        f"INSERT INTO {schema}.sync_watermark (table_name, last_commit_version, last_commit_ts, last_batch_id, rows_upserted, synced_at)\n"
        f"VALUES ('{table_name}', ?, ?, ?, ?, now())\n"
        f"ON CONFLICT (table_name) DO UPDATE SET\n"
        f"    last_commit_version = GREATEST({schema}.sync_watermark.last_commit_version, EXCLUDED.last_commit_version),\n"
        f"    last_commit_ts = EXCLUDED.last_commit_ts, last_batch_id = EXCLUDED.last_batch_id,\n"
        f"    rows_upserted = EXCLUDED.rows_upserted, synced_at = now();"
    )


def event_type_for(change_type: str, status: str, previous_status: Optional[str] = None) -> Optional[str]:
    """
    Map a CDF change on rm_signals to the business event emitted to SCB topics.
    Returns None when nothing should be emitted (e.g. a no-op update, a pre-image).
    """
    if change_type not in CDF_APPLY_TYPES:
        return None
    if change_type == "insert":
        return {"CREATED": "signal.created", "SUPPRESSED": "signal.suppressed"}.get(status)
    # update_postimage: only emit on a real status transition
    if previous_status is not None and previous_status == status:
        return None
    return {"EXPIRED": "signal.expired", "ACTIONED": "signal.actioned"}.get(status)


def kafka_key(customer_token: str) -> str:
    """Partition by customer so a client's signal events stay ordered for consumers."""
    return customer_token


def jdbc_url(host: str, port: int, database: str, extra: Optional[Dict[str, str]] = None) -> str:
    params = {
        "sslmode": "verify-full",
        "ApplicationName": "databricks-wrb-ods-sink",
        "reWriteBatchedInserts": "true",
        "connectTimeout": "10",
        "socketTimeout": "120",
        "options": "-c statement_timeout=110000",
    }
    params.update(extra or {})
    qs = "&".join(f"{k}={v}" for k, v in params.items())
    return f"jdbc:postgresql://{host}:{port}/{database}?{qs}"
