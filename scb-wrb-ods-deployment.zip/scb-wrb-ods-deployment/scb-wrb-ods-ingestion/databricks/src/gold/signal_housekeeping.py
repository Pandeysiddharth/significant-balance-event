"""
Gold housekeeping (every 5 minutes):
  - rm_signals.status CREATED -> EXPIRED when expires_at has passed and no outcome exists
  - rm_signals.status CREATED -> ACTIONED when an outcome has been recorded by the console

Status is kept materialised (rather than only in the rm_signals_active view) so CDF consumers
(Lakebase sync, on-prem Postgres sink, Kafka emit-back) see signal.expired / signal.actioned
transitions as row updates.

Usage: signal_housekeeping.py --market hk
"""
from __future__ import annotations

import argparse
import logging

from pyspark.sql import SparkSession

log = logging.getLogger("signal_housekeeping")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")


def run(market: str) -> None:
    spark = SparkSession.builder.getOrCreate()
    signals = f"wrb_ods.{market}_gold.rm_signals"
    outcomes = f"wrb_ods.{market}_gold.signal_outcomes"

    actioned = spark.sql(f"""
        MERGE INTO {signals} s
        USING (SELECT DISTINCT signal_id FROM {outcomes}) o
        ON s.signal_id = o.signal_id AND s.status = 'CREATED'
        WHEN MATCHED THEN UPDATE SET s.status = 'ACTIONED'
    """).collect()[0]

    expired = spark.sql(f"""
        UPDATE {signals}
        SET status = 'EXPIRED'
        WHERE status = 'CREATED' AND expires_at <= current_timestamp()
    """).collect()[0]

    log.info("market=%s actioned=%s expired=%s", market,
             actioned["num_updated_rows"], expired["num_affected_rows"])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--market", required=True)
    run(ap.parse_args().market)
