"""
Gold: client_30d_baseline refresh.

Runs every 15 minutes (job schedule). Computes per customer_token x direction over the trailing
`baseline_window_days`, excluding the most recent `baseline_exclude_hours` so a large event that
has just happened does not inflate the norm it is being compared against.

Why batch rather than a streaming sliding window: a 30-day sliding window per client is a large
state footprint for marginal freshness benefit; a 15-minute-old baseline is more than adequate for
"30x the norm" logic, and the detection stream picks up the newest as_of_ts each micro-batch.

Only the newest as_of_ts is kept in the table (history goes to Delta time travel), so the
detection join is a plain equality join on customer_token/direction.

Usage: baseline_refresh.py --market hk
"""
from __future__ import annotations

import argparse
import logging
import os
import sys

from pyspark.sql import SparkSession
from pyspark.sql import functions as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rules import Rules  # noqa: E402

log = logging.getLogger("baseline_refresh")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")


def load_rules(spark: SparkSession, market: str) -> Rules:
    rows = spark.table(f"wrb_ods.{market}_gold.signal_rules").select("rule_key", "rule_value").collect()
    return Rules.from_table_rows({r.rule_key: r.rule_value for r in rows})


def run(market: str) -> None:
    spark = SparkSession.builder.getOrCreate()
    rules = load_rules(spark, market)
    silver = f"wrb_ods.{market}_silver.transactions"
    target = f"wrb_ods.{market}_gold.client_30d_baseline"

    as_of = spark.sql("SELECT current_timestamp() AS ts").collect()[0].ts
    window_end = F.lit(as_of) - F.expr(f"INTERVAL {rules.baseline_exclude_hours} HOURS")
    window_start = F.to_date(F.lit(as_of) - F.expr(f"INTERVAL {rules.baseline_window_days} DAYS"))

    txns = (
        spark.table(silver)
        .filter(F.col("event_type") == "TXN_POSTED")
        .filter((F.col("event_date") >= window_start) & (F.col("event_ts") < window_end))
        .filter(F.col("amount_usd").isNotNull())
    )

    daily = (txns.groupBy("customer_token", "direction", "event_date")
                 .agg(F.sum("amount_usd").alias("daily_usd")))
    daily_avg = (daily.groupBy("customer_token", "direction")
                      .agg((F.sum("daily_usd") / F.lit(rules.baseline_window_days)).alias("avg_daily_flow_usd")))

    baseline = (
        txns.groupBy("customer_token", "direction")
        .agg(
            F.count("*").alias("txn_count"),
            F.avg("amount_usd").alias("avg_txn_usd"),
            F.percentile_approx("amount_usd", 0.95).alias("p95_txn_usd"),
            F.max("amount_usd").alias("max_txn_usd"),
            F.stddev_pop("amount_usd").alias("stddev_txn_usd"),
        )
        .join(daily_avg, ["customer_token", "direction"], "left")
        .select(
            "customer_token", "direction",
            window_start.alias("window_start"),
            window_end.alias("window_end"),
            "txn_count",
            F.col("avg_txn_usd").cast("decimal(20,2)"),
            F.col("p95_txn_usd").cast("decimal(20,2)"),
            F.col("max_txn_usd").cast("decimal(20,2)"),
            F.col("avg_daily_flow_usd").cast("decimal(20,2)"),
            F.col("stddev_txn_usd").cast("decimal(20,2)"),
            F.lit(as_of).alias("as_of_ts"),
        )
    )

    # Atomic replace: readers see either the old or the new baseline, never a mix.
    baseline.write.format("delta").mode("overwrite").saveAsTable(target)
    n = spark.table(target).count()
    log.info("baseline refreshed market=%s rows=%s as_of=%s window=%sd exclude=%sh",
             market, n, as_of, rules.baseline_window_days, rules.baseline_exclude_hours)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--market", required=True)
    run(ap.parse_args().market)
