"""
Gold business rules: significance, signal typing/priority, suppression.

Spark-free. The detection job loads rule values from gold.signal_rules each micro-batch,
builds a Rules object, and applies these functions either as UDFs or (for the hot path) as
equivalent column expressions. Tests in tests/test_rules.py are the contract.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Dict, Optional, Tuple

INFLOW_OPPORTUNITY = "INFLOW_OPPORTUNITY"
OUTFLOW_VERIFY = "OUTFLOW_VERIFY"

ABS_CEILING = "ABS_CEILING"
MULTIPLIER = "MULTIPLIER"
HOURLY_OUTFLOW = "HOURLY_OUTFLOW"

# Suppression reasons, in evaluation order (first match wins)
DO_NOT_CONTACT = "DO_NOT_CONTACT"
VULNERABLE_CUSTOMER = "VULNERABLE_CUSTOMER"
ACTIVE_COMPLAINT = "ACTIVE_COMPLAINT"
CONTACT_LIMIT_48H = "CONTACT_LIMIT_48H"
DUPLICATE_WINDOW = "DUPLICATE_WINDOW"
NO_RM_ASSIGNED = "NO_RM_ASSIGNED"


@dataclass(frozen=True)
class Rules:
    baseline_window_days: int = 30
    baseline_exclude_hours: int = 1
    baseline_min_txns: int = 5
    significant_multiplier: Decimal = Decimal("30")
    significant_min_amount_usd: Decimal = Decimal("50000")
    significant_abs_amount_usd: Decimal = Decimal("250000")
    hourly_outflow_usd: Decimal = Decimal("10000000")
    fraud_multiplier: Decimal = Decimal("100")
    max_contacts_48h: int = 3
    signal_ttl_hours: int = 4
    dedupe_window_minutes: int = 60

    @classmethod
    def from_table_rows(cls, rows: Dict[str, str]) -> "Rules":
        """rows: {rule_key: rule_value} as read from gold.signal_rules. Unknown keys ignored."""
        kw = {}
        for k, v in rows.items():
            if k not in cls.__dataclass_fields__:
                continue
            typ = cls.__dataclass_fields__[k].type
            kw[k] = Decimal(v) if typ in ("Decimal", Decimal) else int(v)
        return cls(**kw)

    def snapshot(self) -> Dict[str, str]:
        return {k: str(getattr(self, k)) for k in self.__dataclass_fields__}


def significance(
    amount_usd: Optional[Decimal],
    baseline_avg_txn_usd: Optional[Decimal],
    baseline_txn_count: Optional[int],
    rules: Rules,
) -> Tuple[Optional[str], Optional[Decimal]]:
    """
    Decide whether a single transaction is significant.
    Returns (trigger_rule or None, multiple_of_norm or None).

    Order:
      1. below the absolute floor -> never significant
      2. at/above the absolute ceiling -> ABS_CEILING (even with no baseline)
      3. enough history and amount > multiplier x avg -> MULTIPLIER
      4. otherwise not significant
    """
    if amount_usd is None or amount_usd < rules.significant_min_amount_usd:
        return None, None

    has_baseline = (
        baseline_avg_txn_usd is not None
        and baseline_avg_txn_usd > 0
        and (baseline_txn_count or 0) >= rules.baseline_min_txns
    )
    multiple = (amount_usd / baseline_avg_txn_usd).quantize(Decimal("0.01")) if has_baseline else None

    if amount_usd >= rules.significant_abs_amount_usd:
        return ABS_CEILING, multiple
    if has_baseline and multiple is not None and multiple > rules.significant_multiplier:
        return MULTIPLIER, multiple
    return None, None


def signal_type(direction: str) -> str:
    return INFLOW_OPPORTUNITY if direction == "CREDIT" else OUTFLOW_VERIFY


def fraud_flag(direction: str, multiple_of_norm: Optional[Decimal], counterparty_is_new: bool,
               trigger_rule: Optional[str], rules: Rules) -> bool:
    """Outflows only. New counterparty on any significant outflow, or an extreme multiple, or hourly burst."""
    if direction != "DEBIT":
        return False
    if trigger_rule == HOURLY_OUTFLOW:
        return True
    if counterparty_is_new:
        return True
    return multiple_of_norm is not None and multiple_of_norm >= rules.fraud_multiplier


def priority(stype: str, fraud: bool, multiple_of_norm: Optional[Decimal], amount_usd: Decimal,
             rules: Rules) -> str:
    if fraud:
        return "HIGH"
    if amount_usd >= rules.significant_abs_amount_usd * 4:
        return "HIGH"
    if multiple_of_norm is not None and multiple_of_norm >= rules.significant_multiplier * 2:
        return "HIGH"
    if amount_usd >= rules.significant_abs_amount_usd or (
        multiple_of_norm is not None and multiple_of_norm > rules.significant_multiplier
    ):
        return "MEDIUM"
    return "LOW"


def suppression(
    do_not_contact: Optional[bool],
    vulnerable_customer: Optional[bool],
    open_complaints: Optional[int],
    contacts_last_48h: Optional[int],
    duplicate_in_window: Optional[bool],
    rm_id: Optional[str],
    fraud: bool,
    rules: Rules,
) -> Optional[str]:
    """
    First matching reason wins; None means the signal is raised.

    Fraud-flagged outflows bypass the customer-preference suppressions (do-not-contact,
    vulnerable, complaint) because verifying intent protects the client; they still respect
    the contact limit and dedupe window, and still need an RM.
    """
    if not fraud:
        if do_not_contact:
            return DO_NOT_CONTACT
        if vulnerable_customer:
            return VULNERABLE_CUSTOMER
        if (open_complaints or 0) > 0:
            return ACTIVE_COMPLAINT
    if (contacts_last_48h or 0) >= rules.max_contacts_48h:
        return CONTACT_LIMIT_48H
    if duplicate_in_window:
        return DUPLICATE_WINDOW
    if not rm_id:
        return NO_RM_ASSIGNED
    return None
