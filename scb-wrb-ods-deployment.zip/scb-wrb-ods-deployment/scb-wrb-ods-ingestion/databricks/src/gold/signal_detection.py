"""
Gold: real-time signal detection.

Stream silver.transactions -> per micro-batch:
  1. load current rules, baseline, dim_customer, 48h outcome counts, open signals
  2. SINGLE_TXN significance (abs ceiling / multiplier vs 30d norm)
  3. HOURLY_OUTFLOW: rolling 1h debit sum per customer touched in this batch (looked up in Silver)
  4. write significant_balance_events (pre-suppression, full lineage)
  5. apply suppression + typing + priority -> write rm_signals (CREATED or SUPPRESSED)

All reference joins happen inside foreachBatch against the latest Delta snapshot, so rule or
flag changes take effect on the next micro-batch without a restart.

Usage: signal_detection.py --market hk [--trigger-mode continuous|available_now]
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
from decimal import Decimal

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.window import Window

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import rules as R  # noqa: E402

log = logging.getLogger("signal_detection")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")

LINEAGE = ["bronze_source_topic", "bronze_partition", "bronze_offset", "kafka_ts"]


# ------------------------------------------------------------------------------------------
# UDF factories (closures over the Rules snapshot for this batch)
# ------------------------------------------------------------------------------------------
def make_udfs(rules: R.Rules):
    sig_schema = T.StructType([
        T.StructField("trigger_rule", T.StringType()),
        T.StructField("multiple_of_norm", T.DecimalType(12, 2)),
    ])

    def _sig(amount_usd, avg_txn, txn_count):
        trig, mult = R.significance(
            Decimal(amount_usd) if amount_usd is not None else None,
            Decimal(avg_txn) if avg_txn is not None else None,
            int(txn_count) if txn_count is not None else None,
            rules,
        )
        return (trig, mult)

    def _fraud(direction, mult, cp_new, trig):
        return R.fraud_flag(direction, Decimal(mult) if mult is not None else None, bool(cp_new), trig, rules)

    def _priority(stype, fraud, mult, amount_usd):
        return R.priority(stype, bool(fraud), Decimal(mult) if mult is not None else None,
                          Decimal(amount_usd), rules)

    def _suppress(dnc, vuln, complaints, contacts, dup, rm_id, fraud):
        return R.suppression(dnc, vuln, complaints, contacts, dup, rm_id, bool(fraud), rules)

    return (
        F.udf(_sig, sig_schema),
        F.udf(_fraud, T.BooleanType()),
        F.udf(_priority, T.StringType()),
        F.udf(_suppress, T.StringType()),
    )


# ------------------------------------------------------------------------------------------
# Reference loaders (latest snapshot each batch)
# ------------------------------------------------------------------------------------------
def load_rules(spark: SparkSession, market: str) -> R.Rules:
    rows = spark.table(f"wrb_ods.{market}_gold.signal_rules").select("rule_key", "rule_value").collect()
    return R.Rules.from_table_rows({r.rule_key: r.rule_value for r in rows})


def load_baseline(spark: SparkSession, market: str) -> DataFrame:
    return spark.table(f"wrb_ods.{market}_gold.client_30d_baseline").select(
        "customer_token", "direction",
        F.col("avg_txn_usd").alias("baseline_avg_txn_usd"),
        F.col("txn_count").alias("baseline_txn_count"),
        F.col("as_of_ts").alias("baseline_as_of_ts"),
    )


def load_contacts_48h(spark: SparkSession, market: str) -> DataFrame:
    return (spark.table(f"wrb_ods.{market}_gold.signal_outcomes")
            .filter(F.col("outcome").startswith("CONTACTED"))
            .filter(F.col("contacted_ts") >= F.current_timestamp() - F.expr("INTERVAL 48 HOURS"))
            .groupBy("customer_token").agg(F.count("*").alias("contacts_last_48h")))


def load_recent_signals(spark: SparkSession, market: str, rules: R.Rules) -> DataFrame:
    """Signals raised within the dedupe window: used to suppress near-duplicates."""
    return (spark.table(f"wrb_ods.{market}_gold.rm_signals")
            .filter(F.col("status").isin("CREATED", "ACTIONED"))
            .filter(F.col("created_ts") >= F.current_timestamp()
                    - F.expr(f"INTERVAL {rules.dedupe_window_minutes} MINUTES"))
            .select("customer_token", "signal_type").distinct()
            .withColumn("recent_signal_exists", F.lit(True)))


# ------------------------------------------------------------------------------------------
# Detection
# ------------------------------------------------------------------------------------------
def detect_single_txn(batch: DataFrame, baseline: DataFrame, silver_hist: DataFrame,
                      rules: R.Rules, sig_udf) -> DataFrame:
    b = batch.join(baseline, ["customer_token", "direction"], "left")
    b = b.withColumn("sig", sig_udf("amount_usd", "baseline_avg_txn_usd", "baseline_txn_count"))
    b = b.filter(F.col("sig.trigger_rule").isNotNull())

    # counterparty_is_new: no earlier txn from this customer to this counterparty in the window
    cps = b.select("customer_token", "counterparty_token").filter(F.col("counterparty_token").isNotNull()).distinct()
    seen = (silver_hist.join(cps, ["customer_token", "counterparty_token"])
            .select("customer_token", "counterparty_token").distinct()
            .withColumn("cp_seen", F.lit(True)))
    b = b.join(seen, ["customer_token", "counterparty_token"], "left")
    b = b.withColumn("counterparty_is_new",
                     F.col("counterparty_token").isNotNull() & F.col("cp_seen").isNull())

    return b.select(
        "event_id", F.lit("SINGLE_TXN").alias("detection_type"),
        "customer_token", "account_token", "direction", "event_ts",
        "amount_usd", "currency", "amount",
        "baseline_avg_txn_usd", "baseline_txn_count", "baseline_as_of_ts",
        F.col("sig.multiple_of_norm").alias("multiple_of_norm"),
        F.col("sig.trigger_rule").alias("trigger_rule"),
        "counterparty_token", "counterparty_is_new", *LINEAGE,
    )


def detect_hourly_outflow(batch: DataFrame, silver_hist: DataFrame, rules: R.Rules) -> DataFrame:
    """Rolling 1h DEBIT total for customers that had a debit in this batch."""
    custs = batch.filter(F.col("direction") == "DEBIT").select("customer_token").distinct()
    one_hour_ago = F.current_timestamp() - F.expr("INTERVAL 1 HOUR")
    recent = (silver_hist.join(custs, "customer_token")
              .filter((F.col("direction") == "DEBIT") & (F.col("event_ts") >= one_hour_ago)))
    # include this batch's own debits (Silver may not have them visible yet in the same snapshot)
    recent = recent.select(batch.columns).unionByName(batch.filter(F.col("direction") == "DEBIT")) \
                   .dropDuplicates(["event_id"])

    w = Window.partitionBy("customer_token").orderBy(F.col("event_ts").desc(), F.col("kafka_ts").desc())
    agg = (recent.groupBy("customer_token")
           .agg(F.sum("amount_usd").alias("amount_usd"),
                F.max("event_ts").alias("event_ts"),
                F.count("*").alias("n_txns"))
           .filter(F.col("amount_usd") > F.lit(rules.hourly_outflow_usd)))
    # take lineage from the latest debit in the window so the signal points at a real Kafka offset
    latest = recent.withColumn("rn", F.row_number().over(w)).filter("rn = 1") \
                   .select("customer_token", "account_token", "currency", *LINEAGE)
    out = agg.join(latest, "customer_token")
    return out.select(
        F.concat(F.lit("HOURLY:"), "customer_token", F.lit(":"),
                 F.date_format(F.date_trunc("minute", "event_ts"), "yyyyMMddHHmm")).alias("event_id"),
        F.lit("HOURLY_OUTFLOW").alias("detection_type"),
        "customer_token", "account_token", F.lit("DEBIT").alias("direction"), "event_ts",
        F.col("amount_usd").cast("decimal(20,2)").alias("amount_usd"), "currency",
        F.lit(None).cast("decimal(20,2)").alias("amount"),
        F.lit(None).cast("decimal(20,2)").alias("baseline_avg_txn_usd"),
        F.lit(None).cast("bigint").alias("baseline_txn_count"),
        F.lit(None).cast("timestamp").alias("baseline_as_of_ts"),
        F.lit(None).cast("decimal(12,2)").alias("multiple_of_norm"),
        F.lit(R.HOURLY_OUTFLOW).alias("trigger_rule"),
        F.lit(None).cast("string").alias("counterparty_token"),
        F.lit(False).alias("counterparty_is_new"), *LINEAGE,
    )


def build_signals(events: DataFrame, dim_customer: DataFrame, contacts: DataFrame,
                  recent_signals: DataFrame, rules: R.Rules, fraud_udf, prio_udf, supp_udf) -> DataFrame:
    e = events.withColumn("signal_type",
                          F.when(F.col("direction") == "CREDIT", R.INFLOW_OPPORTUNITY).otherwise(R.OUTFLOW_VERIFY))
    e = e.withColumn("fraud_flag", fraud_udf("direction", "multiple_of_norm", "counterparty_is_new", "trigger_rule"))

    # one signal per customer x type per batch: keep the largest
    w = Window.partitionBy("customer_token", "signal_type").orderBy(F.col("amount_usd").desc())
    e = e.withColumn("rn", F.row_number().over(w))
    e = e.withColumn("dup_in_batch", F.col("rn") > 1).drop("rn")

    e = (e.join(dim_customer, "customer_token", "left")
          .join(contacts, "customer_token", "left")
          .join(recent_signals, ["customer_token", "signal_type"], "left"))
    e = e.withColumn("contacts_last_48h", F.coalesce("contacts_last_48h", F.lit(0)))
    e = e.withColumn("duplicate_in_window", F.col("dup_in_batch") | F.coalesce("recent_signal_exists", F.lit(False)))
    e = e.withColumn("suppression_reason",
                     supp_udf("do_not_contact", "vulnerable_customer", "open_complaints",
                              "contacts_last_48h", "duplicate_in_window", "rm_id", "fraud_flag"))
    e = e.withColumn("priority", prio_udf("signal_type", "fraud_flag", "multiple_of_norm", "amount_usd"))
    now = F.current_timestamp()
    snapshot = F.create_map(*[x for k, v in rules.snapshot().items() for x in (F.lit(k), F.lit(v))])
    return e.select(
        F.sha2(F.concat(F.lit("SIG|"), "event_id"), 256).substr(1, 32).alias("signal_id"),
        "event_id", "customer_token", "account_token", "rm_id", "team_id", "segment",
        "signal_type", "priority", "fraud_flag", "amount_usd", "currency", "amount",
        "multiple_of_norm", "trigger_rule",
        F.when(F.col("suppression_reason").isNull(), "CREATED").otherwise("SUPPRESSED").alias("status"),
        "suppression_reason", "preferred_language", "open_complaints", "contacts_last_48h",
        "event_ts", now.alias("created_ts"),
        (now + F.expr(f"INTERVAL {rules.signal_ttl_hours} HOURS")).alias("expires_at"),
        snapshot.alias("rules_snapshot"),
        "baseline_as_of_ts", *LINEAGE,
        (F.unix_millis(now) - F.unix_millis("kafka_ts")).cast("bigint").alias("signal_latency_ms"),
    )


# ------------------------------------------------------------------------------------------
# Batch writer
# ------------------------------------------------------------------------------------------
def make_batch_writer(spark: SparkSession, market: str):
    silver = f"wrb_ods.{market}_silver.transactions"
    events_tbl = f"wrb_ods.{market}_gold.significant_balance_events"
    signals_tbl = f"wrb_ods.{market}_gold.rm_signals"
    dim_customer_tbl = f"wrb_ods.{market}_silver.dim_customer"
    app_id = f"wrb-ods-gold::{market}::detection"

    def write_batch(batch_df: DataFrame, batch_id: int) -> None:
        batch = batch_df.filter(F.col("event_type") == "TXN_POSTED").filter(F.col("amount_usd").isNotNull()).persist()
        try:
            if batch.isEmpty():
                return
            rules = load_rules(spark, market)
            sig_udf, fraud_udf, prio_udf, supp_udf = make_udfs(rules)
            baseline = load_baseline(spark, market)
            hist = spark.table(silver).filter(
                F.col("event_date") >= F.current_date() - rules.baseline_window_days)
            dim_customer = spark.table(dim_customer_tbl).select(
                "customer_token", "rm_id", "team_id", "segment", "preferred_language",
                "do_not_contact", "vulnerable_customer", "open_complaints")

            single = detect_single_txn(batch, baseline, hist, rules, sig_udf)
            hourly = detect_hourly_outflow(batch, hist, rules)
            events = single.unionByName(hourly).withColumn("detected_ts", F.current_timestamp()).persist()

            n_events = events.count()
            if n_events == 0:
                log.info("batch=%s no significant events", batch_id)
                return

            (events.write.format("delta").mode("append")
                   .option("txnAppId", app_id + "::events").option("txnVersion", batch_id)
                   .saveAsTable(events_tbl))

            signals = build_signals(events, dim_customer, load_contacts_48h(spark, market),
                                    load_recent_signals(spark, market, rules), rules,
                                    fraud_udf, prio_udf, supp_udf)
            (signals.write.format("delta").mode("append")
                    .option("txnAppId", app_id + "::signals").option("txnVersion", batch_id)
                    .saveAsTable(signals_tbl))

            stats = signals.groupBy("status").count().collect()
            log.info("batch=%s significant=%s signals=%s", batch_id, n_events,
                     {r["status"]: r["count"] for r in stats})
            events.unpersist()
        finally:
            batch.unpersist()

    return write_batch


def run(market: str, trigger_mode: str) -> None:
    spark = SparkSession.builder.getOrCreate()
    src = (spark.readStream.format("delta").option("maxFilesPerTrigger", 100)
           .table(f"wrb_ods.{market}_silver.transactions"))
    writer = (src.writeStream.foreachBatch(make_batch_writer(spark, market))
              .option("checkpointLocation", f"/Volumes/wrb_ods/{market}_ops/checkpoints/gold/detection")
              .queryName(f"gold_{market}_detection"))
    writer = writer.trigger(availableNow=True) if trigger_mode == "available_now" \
        else writer.trigger(processingTime="2 seconds")
    writer.start().awaitTermination()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--market", required=True)
    ap.add_argument("--trigger-mode", default="continuous", choices=["continuous", "available_now"])
    a = ap.parse_args()
    run(a.market, a.trigger_mode)
