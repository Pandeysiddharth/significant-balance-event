"""
Tokenization guard logic for the Bronze ingestion job.

Spark-free on purpose: these functions are unit-tested locally and are the same code
that would run on SCB's own Spark Streaming engine (portability requirement).
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import yaml

MISSING_TOKENIZED_HEADER = "MISSING_TOKENIZED_HEADER"
TOKEN_FORMAT_CHECK_FAILED = "TOKEN_FORMAT_CHECK_FAILED"
NOT_JSON = "NOT_JSON"
MISSING_REQUIRED_FIELD = "MISSING_REQUIRED_FIELD"


@dataclass(frozen=True)
class GuardConfig:
    required_header: str
    required_header_value: str
    token_pattern: str
    pii_fields: List[str]
    required_fields: List[str]
    quarantine_rate_alarm: float = 0.01
    event_time_json_path: str = "$.event_time"

    @property
    def token_regex(self) -> "re.Pattern[str]":
        return re.compile(self.token_pattern)


@dataclass(frozen=True)
class TopicConfig:
    market: str
    topic: str
    catalog: str
    bronze_schema: str
    ops_schema: str
    checkpoint_volume: str
    table: str
    guard: GuardConfig
    kafka: Dict[str, Any] = field(default_factory=dict)
    trigger_seconds: int = 2

    @property
    def bronze_table(self) -> str:
        return f"{self.catalog}.{self.bronze_schema}.{self.table}"

    @property
    def quarantine_table(self) -> str:
        return f"{self.catalog}.{self.ops_schema}.bronze_quarantine"

    @property
    def audit_table(self) -> str:
        return f"{self.catalog}.{self.ops_schema}.bronze_ingest_audit"

    @property
    def checkpoint_path(self) -> str:
        safe = self.topic.replace(".", "_")
        return f"{self.checkpoint_volume}/bronze/{safe}"


def load_topic_config(path: str, market: str, topic: str) -> TopicConfig:
    with open(path, "r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh)
    defaults = raw.get("defaults", {})
    mk = raw["markets"][market]
    entry = next((t for t in mk["topics"] if t["topic"] == topic), None)
    if entry is None:
        raise KeyError(f"topic {topic!r} not configured for market {market!r}")
    g = defaults.get("guard", {})
    guard = GuardConfig(
        required_header=g["required_header"],
        required_header_value=g["required_header_value"],
        token_pattern=g["token_pattern"],
        pii_fields=list(entry["pii_fields"]),
        required_fields=list(entry.get("required_fields", [])),
        quarantine_rate_alarm=float(g.get("quarantine_rate_alarm", 0.01)),
        event_time_json_path=g.get("event_time_json_path", "$.event_time"),
    )
    if not set(guard.required_fields) <= set(guard.pii_fields):
        raise ValueError("required_fields must be a subset of pii_fields")
    return TopicConfig(
        market=market,
        topic=topic,
        catalog=mk["catalog"],
        bronze_schema=mk["bronze_schema"],
        ops_schema=mk["ops_schema"],
        checkpoint_volume=mk["checkpoint_volume"],
        table=entry["table"],
        guard=guard,
        kafka=dict(defaults.get("kafka", {})),
        trigger_seconds=int(defaults.get("trigger_seconds", 2)),
    )


def _get_path(obj: Any, dot_path: str) -> Optional[Any]:
    cur = obj
    for part in dot_path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


def check_record(headers: Dict[str, str], payload: Optional[str], cfg: GuardConfig) -> Tuple[Optional[str], Optional[str]]:
    """
    Decide whether a record may land in Bronze.

    Returns (None, None) if the record passes, otherwise (reason, detail).
    Fail-closed: anything we cannot positively verify is refused.
    """
    hv = (headers or {}).get(cfg.required_header)
    if hv is None or hv.lower() != cfg.required_header_value.lower():
        return MISSING_TOKENIZED_HEADER, f"header {cfg.required_header}={hv!r}"

    if payload is None:
        return NOT_JSON, "empty payload"
    try:
        obj = json.loads(payload)
    except (ValueError, TypeError) as exc:
        return NOT_JSON, str(exc)[:200]
    if not isinstance(obj, dict):
        return NOT_JSON, "payload is not a JSON object"

    rx = cfg.token_regex
    for path in cfg.pii_fields:
        val = _get_path(obj, path)
        if val is None or val == "":
            if path in cfg.required_fields:
                return MISSING_REQUIRED_FIELD, path
            continue
        if not isinstance(val, str) or not rx.match(val):
            # Do not echo the value: if it is clear text we must not persist it anywhere.
            return TOKEN_FORMAT_CHECK_FAILED, path
    return None, None


def quarantine_rate_exceeded(rows_in: int, rows_quarantined: int, cfg: GuardConfig) -> bool:
    if rows_in == 0:
        return False
    return (rows_quarantined / rows_in) > cfg.quarantine_rate_alarm
