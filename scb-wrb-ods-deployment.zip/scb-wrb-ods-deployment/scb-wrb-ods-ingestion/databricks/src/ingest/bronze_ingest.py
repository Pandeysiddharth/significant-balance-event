"""
Bronze ingestion: Azure-mirrored Kafka topic (already tokenized by the on-prem bridge) -> Delta.

Guarantees
  - Exactly-once into Bronze via Kafka offsets in the checkpoint + idempotent Delta writes
    (txnAppId/txnVersion) across the two tables written per micro-batch.
  - Fail-closed tokenization guard: a record lands in Bronze only if
      (a) header x-pii-tokenized=true is present, and
      (b) every configured PII field that is present matches the agreed token pattern, and
      (c) every required PII field is present.
    Anything else goes to quarantine as metadata + hash (payload is NOT persisted).
  - Per-batch audit row with broker->Bronze latency, used by the Architect view.

Usage (spark_python_task):
  bronze_ingest.py --market hk --topic wrb.ods.hk.core_banking.tokenized --config /path/topics.yml
Optional:
  --trigger-mode continuous|available_now   (default continuous micro-batch at trigger_seconds)
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
import uuid

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from guard import (  # noqa: E402
    GuardConfig,
    TopicConfig,
    check_record,
    load_topic_config,
    quarantine_rate_exceeded,
)

log = logging.getLogger("bronze_ingest")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")


# --------------------------------------------------------------------------------------
# Kafka source
# --------------------------------------------------------------------------------------
def _secret(dbutils, ref: str) -> str:
    scope, key = ref.split("/", 1)
    return dbutils.secrets.get(scope=scope, key=key)


def kafka_options(cfg: TopicConfig, dbutils) -> dict:
    k = cfg.kafka
    client_id = _secret(dbutils, k["oauth_client_id_secret"])
    client_secret = _secret(dbutils, k["oauth_client_secret_secret"])
    token_endpoint = _secret(dbutils, k["oauth_token_endpoint_secret"])
    scope = _secret(dbutils, k["oauth_scope_secret"])
    jaas = (
        "kafkashaded.org.apache.kafka.common.security.oauthbearer.OAuthBearerLoginModule required "
        f'clientId="{client_id}" clientSecret="{client_secret}" scope="{scope}";'
    )
    return {
        "kafka.bootstrap.servers": _secret(dbutils, k["bootstrap_servers_secret"]),
        "kafka.security.protocol": "SASL_SSL",
        "kafka.sasl.mechanism": "OAUTHBEARER",
        "kafka.sasl.jaas.config": jaas,
        "kafka.sasl.oauthbearer.token.endpoint.url": token_endpoint,
        "kafka.sasl.login.callback.handler.class": (
            "kafkashaded.org.apache.kafka.common.security.oauthbearer.secured."
            "OAuthBearerLoginCallbackHandler"
        ),
        "subscribe": cfg.topic,
        "startingOffsets": k.get("starting_offsets", "earliest"),
        "maxOffsetsPerTrigger": str(k.get("max_offsets_per_trigger", 200000)),
        "failOnDataLoss": str(k.get("fail_on_data_loss", False)).lower(),
        "includeHeaders": "true",
        "groupIdPrefix": f"wrb-ods-bronze-{cfg.market}",
    }


def read_kafka(spark: SparkSession, cfg: TopicConfig, dbutils) -> DataFrame:
    return spark.readStream.format("kafka").options(**kafka_options(cfg, dbutils)).load()


# --------------------------------------------------------------------------------------
# Transform + guard
# --------------------------------------------------------------------------------------
GUARD_RESULT = T.StructType(
    [T.StructField("reason", T.StringType()), T.StructField("detail", T.StringType())]
)


def make_guard_udf(guard: GuardConfig):
    # Closure over a frozen dataclass; serialises cleanly to executors.
    def _guard(headers, payload):
        reason, detail = check_record(headers or {}, payload, guard)
        return (reason, detail)

    return F.udf(_guard, GUARD_RESULT)


def shape(raw: DataFrame, cfg: TopicConfig, run_id: str) -> DataFrame:
    guard_udf = make_guard_udf(cfg.guard)
    headers_map = F.expr(
        "map_from_entries(transform(headers, h -> struct(h.key, cast(h.value as string))))"
    )
    df = raw.select(
        F.col("key").cast("string").alias("event_key"),
        F.col("value").cast("string").alias("payload"),
        headers_map.alias("headers"),
        F.col("topic").alias("source_topic"),
        F.col("partition").alias("source_partition"),
        F.col("offset").alias("source_offset"),
        F.col("timestamp").alias("kafka_ts"),
    )
    df = df.withColumn("guard", guard_udf(F.col("headers"), F.col("payload")))
    df = df.withColumn(
        "event_ts",
        F.to_timestamp(F.get_json_object(F.col("payload"), cfg.guard.event_time_json_path)),
    )
    df = df.withColumn(
        "tokenization_scheme", F.get_json_object(F.col("payload"), "$._tokenization_scheme")
    )
    return df.withColumn("ingest_run_id", F.lit(run_id))


def split_good_bad(shaped: DataFrame):
    good = shaped.filter(F.col("guard.reason").isNull()).select(
        "event_key",
        "payload",
        "tokenization_scheme",
        "headers",
        "source_topic",
        "source_partition",
        "source_offset",
        "kafka_ts",
        "event_ts",
        F.current_timestamp().alias("ingest_ts"),
        "ingest_run_id",
    )
    # Quarantine never carries the payload. Hash only.
    bad = shaped.filter(F.col("guard.reason").isNotNull()).select(
        "source_topic",
        "source_partition",
        "source_offset",
        "kafka_ts",
        "event_key",
        F.sha2(F.coalesce(F.col("payload"), F.lit("")), 256).alias("payload_sha256"),
        "headers",
        F.col("guard.reason").alias("reason"),
        F.col("guard.detail").alias("detail"),
        F.current_timestamp().alias("ingest_ts"),
        "ingest_run_id",
    )
    return good, bad


# --------------------------------------------------------------------------------------
# Sink: foreachBatch so Bronze + quarantine + audit are written per batch, idempotently
# --------------------------------------------------------------------------------------
def make_batch_writer(spark: SparkSession, cfg: TopicConfig, run_id: str):
    app_id = f"wrb-ods-bronze::{cfg.topic}"

    def write_batch(batch_df: DataFrame, batch_id: int) -> None:
        batch_df = batch_df.persist()
        try:
            good, bad = split_good_bad(batch_df)

            stats = batch_df.agg(
                F.count("*").alias("rows_in"),
                F.sum(F.when(F.col("guard.reason").isNotNull(), 1).otherwise(0)).alias("rows_bad"),
                F.min("kafka_ts").alias("min_kafka_ts"),
                F.max("kafka_ts").alias("max_kafka_ts"),
            ).collect()[0]
            rows_in = int(stats["rows_in"] or 0)
            rows_bad = int(stats["rows_bad"] or 0)

            (
                good.write.format("delta")
                .mode("append")
                .option("txnAppId", app_id)
                .option("txnVersion", batch_id)
                .saveAsTable(cfg.bronze_table)
            )
            if rows_bad:
                (
                    bad.write.format("delta")
                    .mode("append")
                    .option("txnAppId", app_id + "::quarantine")
                    .option("txnVersion", batch_id)
                    .saveAsTable(cfg.quarantine_table)
                )

            audit = spark.createDataFrame(
                [
                    (
                        run_id,
                        cfg.topic,
                        cfg.bronze_table,
                        int(batch_id),
                        rows_in,
                        rows_in - rows_bad,
                        rows_bad,
                        stats["min_kafka_ts"],
                        stats["max_kafka_ts"],
                    )
                ],
                "ingest_run_id string, source_topic string, target_table string, batch_id bigint, "
                "rows_in bigint, rows_written bigint, rows_quarantined bigint, "
                "min_kafka_ts timestamp, max_kafka_ts timestamp",
            ).withColumn("batch_end_ts", F.current_timestamp())
            audit = audit.withColumn(
                "max_latency_ms",
                (F.unix_millis("batch_end_ts") - F.unix_millis("min_kafka_ts")).cast("bigint"),
            )
            (
                audit.write.format("delta")
                .mode("append")
                .option("txnAppId", app_id + "::audit")
                .option("txnVersion", batch_id)
                .saveAsTable(cfg.audit_table)
            )

            if quarantine_rate_exceeded(rows_in, rows_bad, cfg.guard):
                # Keep the stream alive (good rows are safe) but make the failure loud. The job
                # has an alert on this log line and on the quarantine table growth.
                log.error(
                    "QUARANTINE RATE ALARM topic=%s batch=%s rows_in=%s quarantined=%s "
                    "-- bridge tokenization SMT is probably failing",
                    cfg.topic, batch_id, rows_in, rows_bad,
                )
            else:
                log.info(
                    "batch=%s topic=%s rows_in=%s written=%s quarantined=%s",
                    batch_id, cfg.topic, rows_in, rows_in - rows_bad, rows_bad,
                )
        finally:
            batch_df.unpersist()

    return write_batch


# --------------------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------------------
def run(market: str, topic: str, config_path: str, trigger_mode: str) -> None:
    spark = SparkSession.builder.getOrCreate()
    try:
        from pyspark.dbutils import DBUtils  # type: ignore

        dbutils = DBUtils(spark)
    except Exception:  # pragma: no cover - local/portable mode
        dbutils = None
    if dbutils is None:
        raise RuntimeError(
            "dbutils unavailable. For non-Databricks Spark, inject Kafka credentials via "
            "environment and replace kafka_options(); see README 'Portability'."
        )

    cfg = load_topic_config(config_path, market, topic)
    run_id = str(uuid.uuid4())
    log.info("starting bronze ingest run_id=%s topic=%s -> %s", run_id, topic, cfg.bronze_table)

    raw = read_kafka(spark, cfg, dbutils)
    shaped = shape(raw, cfg, run_id)

    writer = (
        shaped.writeStream.foreachBatch(make_batch_writer(spark, cfg, run_id))
        .option("checkpointLocation", cfg.checkpoint_path)
        .queryName(f"bronze_{cfg.market}_{cfg.table}")
    )
    if trigger_mode == "available_now":
        writer = writer.trigger(availableNow=True)
    else:
        writer = writer.trigger(processingTime=f"{cfg.trigger_seconds} seconds")

    query = writer.start()
    query.awaitTermination()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--market", required=True)
    ap.add_argument("--topic", required=True)
    ap.add_argument("--config", required=True)
    ap.add_argument("--trigger-mode", default="continuous", choices=["continuous", "available_now"])
    a = ap.parse_args()
    run(a.market, a.topic, a.config, a.trigger_mode)
