"""
Silver: Bronze core_banking_events -> silver.transactions

  - from_json with an explicit schema (no inference in the hot path)
  - watermark on event_ts + dropDuplicatesWithinWatermark(event_id): exactly one row per event
    even if the bridge or MM2 redelivers
  - data-quality expectations: failures go to transactions_quarantine (payload is tokenized,
    so retaining it is fine), passes continue
  - FX normalisation to USD via stream-static join to ref_fx_rates (latest rate <= event date,
    falling back to the most recent rate available for the currency)

Usage: silver_transactions.py --market hk [--trigger-mode continuous|available_now]
"""
from __future__ import annotations

import argparse
import logging
import os
import sys

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dq import EXPECTATIONS, failed_checks_expr  # noqa: E402

log = logging.getLogger("silver_transactions")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")

# Canonical tokenized event shape as published by the bridge. Field paths for PII match the
# bridge SMT config: customer.id, customer.name, customer.national_id, account.number,
# counterparty.account, counterparty.name, narrative.
EVENT_SCHEMA = T.StructType([
    T.StructField("event_id", T.StringType()),
    T.StructField("event_type", T.StringType()),
    T.StructField("event_time", T.StringType()),
    T.StructField("source_system", T.StringType()),
    T.StructField("market", T.StringType()),
    T.StructField("customer", T.StructType([
        T.StructField("id", T.StringType()),
        T.StructField("name", T.StringType()),
        T.StructField("national_id", T.StringType()),
    ])),
    T.StructField("account", T.StructType([
        T.StructField("number", T.StringType()),
        T.StructField("type", T.StringType()),
        T.StructField("currency", T.StringType()),
    ])),
    T.StructField("transaction", T.StructType([
        T.StructField("txn_id", T.StringType()),
        T.StructField("direction", T.StringType()),
        T.StructField("amount", T.DecimalType(20, 2)),
        T.StructField("currency", T.StringType()),
        T.StructField("channel", T.StringType()),
        T.StructField("booking_date", T.StringType()),
        T.StructField("value_date", T.StringType()),
    ])),
    T.StructField("counterparty", T.StructType([
        T.StructField("account", T.StringType()),
        T.StructField("name", T.StringType()),
        T.StructField("bank", T.StringType()),
    ])),
    T.StructField("narrative", T.StringType()),
    T.StructField("balance", T.StructType([
        T.StructField("available", T.DecimalType(20, 2)),
        T.StructField("ledger", T.DecimalType(20, 2)),
        T.StructField("currency", T.StringType()),
    ])),
    T.StructField("_tokenization_scheme", T.StringType()),
])


def parse(bronze: DataFrame) -> DataFrame:
    e = F.from_json(F.col("payload"), EVENT_SCHEMA)
    return bronze.select(
        e.alias("e"),
        F.col("payload"),
        F.col("source_topic").alias("bronze_source_topic"),
        F.col("source_partition").alias("bronze_partition"),
        F.col("source_offset").alias("bronze_offset"),
        F.col("kafka_ts"),
        F.col("ingest_ts").alias("bronze_ingest_ts"),
    ).select(
        F.col("e.event_id").alias("event_id"),
        F.upper(F.col("e.event_type")).alias("event_type"),
        F.to_timestamp(F.col("e.event_time")).alias("event_ts"),
        F.col("e.source_system").alias("source_system"),
        F.lower(F.col("e.market")).alias("market"),
        F.col("e.customer.id").alias("customer_token"),
        F.col("e.account.number").alias("account_token"),
        F.col("e.account.type").alias("account_type"),
        F.col("e.transaction.txn_id").alias("txn_id"),
        F.upper(F.col("e.transaction.direction")).alias("direction"),
        F.col("e.transaction.amount").alias("amount"),
        F.upper(F.col("e.transaction.currency")).alias("currency"),
        F.col("e.transaction.channel").alias("channel"),
        F.to_date(F.col("e.transaction.booking_date")).alias("booking_date"),
        F.to_date(F.col("e.transaction.value_date")).alias("value_date"),
        F.col("e.counterparty.account").alias("counterparty_token"),
        F.col("e.counterparty.name").alias("counterparty_name_token"),
        F.col("e.counterparty.bank").alias("counterparty_bank"),
        F.col("e.narrative").alias("narrative_token"),
        F.col("e.balance.available").alias("balance_available"),
        F.col("e.balance.ledger").alias("balance_ledger"),
        F.upper(F.col("e.balance.currency")).alias("balance_currency"),
        "payload",
        "bronze_source_topic",
        "bronze_partition",
        "bronze_offset",
        "kafka_ts",
        "bronze_ingest_ts",
    )


def dedupe(df: DataFrame, watermark: str = "2 hours") -> DataFrame:
    # Events with unparseable event_ts cannot be watermarked; they fail DQ later. Give them the
    # Kafka timestamp so they still flow through the dedupe operator instead of being dropped.
    df = df.withColumn("event_ts_wm", F.coalesce(F.col("event_ts"), F.col("kafka_ts")))
    return (
        df.withWatermark("event_ts_wm", watermark)
        .dropDuplicatesWithinWatermark(["event_id"])
        .drop("event_ts_wm")
    )


def apply_dq(df: DataFrame):
    df = df.withColumn("failed_checks", failed_checks_expr(EXPECTATIONS))
    good = df.filter(F.size("failed_checks") == 0).drop("failed_checks", "payload")
    bad = df.filter(F.size("failed_checks") > 0).select(
        "event_id", "failed_checks", "payload",
        "bronze_source_topic", "bronze_partition", "bronze_offset",
        F.current_timestamp().alias("silver_ts"),
    )
    return good, bad


def latest_fx(spark: SparkSession, fx_table: str) -> DataFrame:
    """One rate per (currency, rate_date) is assumed; we also build a 'latest known' fallback."""
    fx = spark.table(fx_table).select("currency", "rate_date", "rate_to_usd")
    w_latest = fx.groupBy("currency").agg(F.max("rate_date").alias("rate_date"))
    fallback = fx.join(w_latest, ["currency", "rate_date"]).select(
        "currency", F.col("rate_to_usd").alias("fallback_rate_to_usd")
    )
    return fx, fallback


def add_fx(good: DataFrame, fx: DataFrame, fallback: DataFrame) -> DataFrame:
    # Rate as of event date; if none for that exact date (weekend/holiday), use the latest rate.
    # USD rows have rate 1.0 in the reference table.
    g = good.alias("g")
    joined = (
        g.join(fx.alias("fx"),
               (F.col("g.currency") == F.col("fx.currency"))
               & (F.col("fx.rate_date") == F.to_date(F.col("g.event_ts"))), "left")
         .join(fallback.alias("fb"), F.col("g.currency") == F.col("fb.currency"), "left")
    )
    rate = F.coalesce(F.col("fx.rate_to_usd"), F.col("fb.fallback_rate_to_usd"),
                      F.when(F.col("g.currency") == "USD", F.lit(1.0)))
    return (
        joined.select("g.*", rate.cast("decimal(18,8)").alias("fx_rate_to_usd"))
        .withColumn("amount_usd", (F.col("amount") * F.col("fx_rate_to_usd")).cast("decimal(20,2)"))
        .withColumn("silver_ts", F.current_timestamp())
    )


def make_batch_writer(spark: SparkSession, market: str):
    silver = f"wrb_ods.{market}_silver.transactions"
    quarantine = f"wrb_ods.{market}_silver.transactions_quarantine"
    fx_table = f"wrb_ods.{market}_silver.ref_fx_rates"
    app_id = f"wrb-ods-silver::{market}::transactions"

    def write_batch(batch_df: DataFrame, batch_id: int) -> None:
        batch_df = batch_df.persist()
        try:
            good, bad = apply_dq(batch_df)
            fx, fallback = latest_fx(spark, fx_table)
            good = add_fx(good, fx, fallback)
            cols = [c for c in spark.table(silver).columns if c != "event_date"]
            (good.select(*cols).write.format("delta").mode("append")
                 .option("txnAppId", app_id).option("txnVersion", batch_id).saveAsTable(silver))
            n_bad = bad.count()
            if n_bad:
                (bad.write.format("delta").mode("append")
                    .option("txnAppId", app_id + "::quarantine").option("txnVersion", batch_id)
                    .saveAsTable(quarantine))
            log.info("batch=%s silver rows written, quarantined=%s", batch_id, n_bad)
        finally:
            batch_df.unpersist()

    return write_batch


def run(market: str, trigger_mode: str) -> None:
    spark = SparkSession.builder.getOrCreate()
    bronze = f"wrb_ods.{market}_bronze.core_banking_events"
    checkpoint = f"/Volumes/wrb_ods/{market}_ops/checkpoints/silver/transactions"

    src = (spark.readStream.format("delta")
           .option("maxFilesPerTrigger", 200)
           .table(bronze))
    df = dedupe(parse(src))

    writer = (df.writeStream.foreachBatch(make_batch_writer(spark, market))
                .option("checkpointLocation", checkpoint)
                .queryName(f"silver_{market}_transactions"))
    writer = writer.trigger(availableNow=True) if trigger_mode == "available_now" \
        else writer.trigger(processingTime="2 seconds")
    writer.start().awaitTermination()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--market", required=True)
    ap.add_argument("--trigger-mode", default="continuous", choices=["continuous", "available_now"])
    a = ap.parse_args()
    run(a.market, a.trigger_mode)
