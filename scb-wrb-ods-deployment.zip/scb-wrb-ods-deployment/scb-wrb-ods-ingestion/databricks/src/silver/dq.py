"""
Silver data-quality expectations. Each expectation is (name, SQL boolean expression that must be TRUE).
Kept as plain SQL strings so they are portable and reviewable by WRB without reading PySpark.
"""
from __future__ import annotations

from typing import List, Tuple

from pyspark.sql import Column
from pyspark.sql import functions as F

EXPECTATIONS: List[Tuple[str, str]] = [
    ("event_id_present",        "event_id IS NOT NULL AND length(event_id) > 0"),
    ("event_ts_parseable",      "event_ts IS NOT NULL"),
    ("event_ts_not_future",     "event_ts <= current_timestamp() + INTERVAL 15 MINUTES"),
    ("event_ts_not_stale",      "event_ts >= current_timestamp() - INTERVAL 400 DAYS"),
    ("customer_token_present",  "customer_token IS NOT NULL"),
    ("account_token_present",   "account_token IS NOT NULL"),
    ("event_type_known",        "event_type IN ('TXN_POSTED','BALANCE_UPDATED')"),
    ("txn_fields_consistent",   "event_type <> 'TXN_POSTED' OR (amount IS NOT NULL AND amount > 0 AND direction IN ('CREDIT','DEBIT'))"),
    ("currency_iso3",           "event_type <> 'TXN_POSTED' OR currency RLIKE '^[A-Z]{3}$'"),
    ("balance_fields_consistent","event_type <> 'BALANCE_UPDATED' OR balance_available IS NOT NULL"),
]


def failed_checks_expr(expectations: List[Tuple[str, str]]) -> Column:
    """Array of names of expectations that evaluated to FALSE/NULL for the row."""
    parts = [F.when(~F.coalesce(F.expr(sql), F.lit(False)), F.lit(name)) for name, sql in expectations]
    return F.array_compact(F.array(*parts))
