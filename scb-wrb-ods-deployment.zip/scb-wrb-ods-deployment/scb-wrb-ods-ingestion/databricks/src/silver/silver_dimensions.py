"""
Silver dimensions: MERGE customer and account profiles from Bronze reference events.

Source: Bronze table <market>_bronze.customer_profile_events, fed by a second bridge connector on
the customer-profile / CRM-preference Solace queue, tokenized with the same scheme so tokens join.
Expected payload (tokenized):
  { "event_id", "event_time", "customer": {"id"}, "profile": {segment, rm_id, team_id, preferred_language,
    do_not_contact, vulnerable_customer, open_complaints, risk_rating, onboarded_date},
    "accounts": [ {"number", "type", "currency", "status", "opened_date"} ] }

Runs as a stream with foreachBatch MERGE so the latest event per customer wins.
Usage: silver_dimensions.py --market hk [--trigger-mode continuous|available_now]
"""
from __future__ import annotations

import argparse
import logging

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.window import Window
from delta.tables import DeltaTable

log = logging.getLogger("silver_dimensions")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")

PROFILE_SCHEMA = T.StructType([
    T.StructField("event_id", T.StringType()),
    T.StructField("event_time", T.StringType()),
    T.StructField("market", T.StringType()),
    T.StructField("customer", T.StructType([T.StructField("id", T.StringType())])),
    T.StructField("profile", T.StructType([
        T.StructField("segment", T.StringType()),
        T.StructField("rm_id", T.StringType()),
        T.StructField("team_id", T.StringType()),
        T.StructField("preferred_language", T.StringType()),
        T.StructField("do_not_contact", T.BooleanType()),
        T.StructField("vulnerable_customer", T.BooleanType()),
        T.StructField("open_complaints", T.IntegerType()),
        T.StructField("risk_rating", T.StringType()),
        T.StructField("onboarded_date", T.StringType()),
    ])),
    T.StructField("accounts", T.ArrayType(T.StructType([
        T.StructField("number", T.StringType()),
        T.StructField("type", T.StringType()),
        T.StructField("currency", T.StringType()),
        T.StructField("status", T.StringType()),
        T.StructField("opened_date", T.StringType()),
    ]))),
])


def parse(bronze: DataFrame) -> DataFrame:
    e = F.from_json("payload", PROFILE_SCHEMA).alias("e")
    return bronze.select(e, "kafka_ts").select(
        F.col("e.event_id").alias("event_id"),
        F.to_timestamp("e.event_time").alias("event_ts"),
        F.lower("e.market").alias("market"),
        F.col("e.customer.id").alias("customer_token"),
        F.col("e.profile.*"),
        F.col("e.accounts").alias("accounts"),
        "kafka_ts",
    ).filter(F.col("customer_token").isNotNull())


def latest_per_customer(df: DataFrame) -> DataFrame:
    # Within a batch, keep the most recent profile event per customer.
    w = F.row_number().over(
        Window.partitionBy("customer_token")
        .orderBy(F.col("event_ts").desc_nulls_last(), F.col("kafka_ts").desc())
    )
    return df.withColumn("rn", w).filter("rn = 1").drop("rn")


def make_batch_writer(spark: SparkSession, market: str):
    dim_customer = f"wrb_ods.{market}_silver.dim_customer"
    dim_account = f"wrb_ods.{market}_silver.dim_account"

    def write_batch(batch_df: DataFrame, batch_id: int) -> None:
        latest = latest_per_customer(batch_df).persist()
        try:
            cust = latest.select(
                "customer_token", "market", "segment", "rm_id", "team_id", "preferred_language",
                F.coalesce("do_not_contact", F.lit(False)).alias("do_not_contact"),
                F.coalesce("vulnerable_customer", F.lit(False)).alias("vulnerable_customer"),
                F.coalesce("open_complaints", F.lit(0)).alias("open_complaints"),
                "risk_rating",
                F.to_date("onboarded_date").alias("onboarded_date"),
                F.col("event_ts").alias("valid_from"),
                F.current_timestamp().alias("updated_ts"),
            )
            (DeltaTable.forName(spark, dim_customer).alias("t")
             .merge(cust.alias("s"), "t.customer_token = s.customer_token")
             .whenMatchedUpdateAll(condition="s.valid_from >= t.valid_from OR t.valid_from IS NULL")
             .whenNotMatchedInsertAll()
             .execute())

            acct = (latest.select("customer_token", F.explode_outer("accounts").alias("a"))
                    .filter(F.col("a.number").isNotNull())
                    .select(
                        F.col("a.number").alias("account_token"), "customer_token",
                        F.col("a.type").alias("account_type"), F.upper("a.currency").alias("currency"),
                        F.col("a.status").alias("status"), F.to_date("a.opened_date").alias("opened_date"),
                        F.current_timestamp().alias("updated_ts"),
                    ).dropDuplicates(["account_token"]))
            (DeltaTable.forName(spark, dim_account).alias("t")
             .merge(acct.alias("s"), "t.account_token = s.account_token")
             .whenMatchedUpdateAll()
             .whenNotMatchedInsertAll()
             .execute())
            log.info("batch=%s dim_customer upserts=%s dim_account upserts=%s", batch_id, cust.count(), acct.count())
        finally:
            latest.unpersist()

    return write_batch


def run(market: str, trigger_mode: str) -> None:
    spark = SparkSession.builder.getOrCreate()
    bronze = f"wrb_ods.{market}_bronze.customer_profile_events"
    checkpoint = f"/Volumes/wrb_ods/{market}_ops/checkpoints/silver/dimensions"
    src = spark.readStream.format("delta").table(bronze)
    writer = (parse(src).writeStream.foreachBatch(make_batch_writer(spark, market))
              .option("checkpointLocation", checkpoint).queryName(f"silver_{market}_dimensions"))
    writer = writer.trigger(availableNow=True) if trigger_mode == "available_now" \
        else writer.trigger(processingTime="10 seconds")
    writer.start().awaitTermination()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--market", required=True)
    ap.add_argument("--trigger-mode", default="continuous", choices=["continuous", "available_now"])
    a = ap.parse_args()
    run(a.market, a.trigger_mode)
