-- WRB ODS: catalog and Bronze layer objects for one market.
-- Run once per market with: :market (hk | sg | in), :storage_root (abfss://... on SCB ADLS)
-- Everything in this catalog holds TOKENIZED data only. The Bronze job enforces that.

CREATE CATALOG IF NOT EXISTS wrb_ods
  MANAGED LOCATION '${storage_root}/wrb_ods'
  COMMENT 'WRB Operational Data Store. Tokenized data only; no clear-text PII is permitted in this catalog.';

CREATE SCHEMA IF NOT EXISTS wrb_ods.${market}_bronze
  COMMENT 'Raw tokenized events as received from the Azure-mirrored Kafka topics. Append-only.';

CREATE SCHEMA IF NOT EXISTS wrb_ods.${market}_ops
  COMMENT 'Operational tables for ingestion: quarantine, audit, checkpoints volume.';

CREATE VOLUME IF NOT EXISTS wrb_ods.${market}_ops.checkpoints
  COMMENT 'Structured Streaming checkpoints for Bronze ingestion.';

-- One Bronze table per topic family. Same shape for all so the ingest job is generic.
CREATE TABLE IF NOT EXISTS wrb_ods.${market}_bronze.core_banking_events (
  event_key            STRING    COMMENT 'Kafka record key (Solace correlation id)',
  payload              STRING    COMMENT 'Tokenized JSON payload, verbatim from the topic',
  tokenization_scheme  STRING    COMMENT 'Scheme stamped by the bridge SMT',
  headers              MAP<STRING, STRING> COMMENT 'Kafka headers incl. x-pii-tokenized',
  source_topic         STRING,
  source_partition     INT,
  source_offset        BIGINT,
  kafka_ts             TIMESTAMP COMMENT 'Broker timestamp',
  event_ts             TIMESTAMP COMMENT 'Business event time from payload ($.event_time), if present',
  ingest_ts            TIMESTAMP COMMENT 'Time the row was written to Bronze',
  ingest_run_id        STRING,
  ingest_date          DATE GENERATED ALWAYS AS (CAST(ingest_ts AS DATE))
)
USING DELTA
PARTITIONED BY (ingest_date)
TBLPROPERTIES (
  'delta.enableChangeDataFeed' = 'true',
  'delta.autoOptimize.optimizeWrite' = 'true',
  'delta.autoOptimize.autoCompact' = 'true',
  'delta.logRetentionDuration' = 'interval 90 days',
  'delta.deletedFileRetentionDuration' = 'interval 30 days',
  'pii.classification' = 'tokenized',
  'quality' = 'bronze'
)
COMMENT 'Bronze: core banking events (transactions, balances, account events). Tokenized. Append-only.';

-- Same shape for the other topic families landed by the generic Bronze job.
CREATE TABLE IF NOT EXISTS wrb_ods.${market}_bronze.customer_profile_events
  LIKE wrb_ods.${market}_bronze.core_banking_events
  COMMENT 'Bronze: customer profile / CRM preference events. Tokenized. Append-only.';
CREATE TABLE IF NOT EXISTS wrb_ods.${market}_bronze.signal_outcome_events
  LIKE wrb_ods.${market}_bronze.core_banking_events
  COMMENT 'Bronze: RM outcome events published back from the on-prem ODS outbox. Tokenized. Append-only.';

-- Quarantine deliberately does NOT store the payload: a record is quarantined because we could not
-- prove it is tokenized, so persisting it would defeat the control. Store coordinates + hash so ops
-- can locate and replay the record from the on-prem topic after fixing the bridge.
CREATE TABLE IF NOT EXISTS wrb_ods.${market}_ops.bronze_quarantine (
  source_topic         STRING,
  source_partition     INT,
  source_offset        BIGINT,
  kafka_ts             TIMESTAMP,
  event_key            STRING,
  payload_sha256       STRING    COMMENT 'Hash of the payload for correlation; payload itself is not stored',
  headers              MAP<STRING, STRING>,
  reason               STRING    COMMENT 'MISSING_TOKENIZED_HEADER | TOKEN_FORMAT_CHECK_FAILED | NOT_JSON | MISSING_REQUIRED_FIELD',
  detail               STRING,
  ingest_ts            TIMESTAMP,
  ingest_run_id        STRING
)
USING DELTA
TBLPROPERTIES ('quality' = 'ops')
COMMENT 'Records refused by the Bronze tokenization guard. Metadata only.';

CREATE TABLE IF NOT EXISTS wrb_ods.${market}_ops.bronze_ingest_audit (
  ingest_run_id        STRING,
  source_topic         STRING,
  target_table         STRING,
  batch_id             BIGINT,
  rows_in              BIGINT,
  rows_written         BIGINT,
  rows_quarantined     BIGINT,
  min_kafka_ts         TIMESTAMP,
  max_kafka_ts         TIMESTAMP,
  batch_end_ts         TIMESTAMP,
  max_latency_ms       BIGINT    COMMENT 'batch_end_ts - min_kafka_ts: worst-case broker-to-bronze latency in the batch'
)
USING DELTA
COMMENT 'Per micro-batch ingestion metrics. Feeds the Architect latency view.';

-- Least privilege: the ingest service principal writes; analysts read Bronze; nobody else reads ops.
GRANT USE CATALOG ON CATALOG wrb_ods TO `wrb-ods-ingest-sp`;
GRANT USE SCHEMA, CREATE TABLE, MODIFY, SELECT ON SCHEMA wrb_ods.${market}_bronze TO `wrb-ods-ingest-sp`;
GRANT USE SCHEMA, CREATE TABLE, MODIFY, SELECT, READ VOLUME, WRITE VOLUME ON SCHEMA wrb_ods.${market}_ops TO `wrb-ods-ingest-sp`;
GRANT USE SCHEMA, SELECT ON SCHEMA wrb_ods.${market}_bronze TO `wrb-ods-engineers`;
GRANT USE SCHEMA, SELECT ON SCHEMA wrb_ods.${market}_ops TO `wrb-ods-platform-ops`;
