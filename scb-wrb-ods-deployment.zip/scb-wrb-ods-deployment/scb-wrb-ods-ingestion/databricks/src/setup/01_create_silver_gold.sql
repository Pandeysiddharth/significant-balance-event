-- WRB ODS: Silver and Gold objects for one market. Parameters: :market, :storage_root
-- All customer / account identifiers in this catalog are TOKENS (deterministic scheme from the
-- bridge). They join to each other and to on-prem reference data by token, never by clear value.

CREATE SCHEMA IF NOT EXISTS wrb_ods.${market}_silver
  COMMENT 'Typed, deduplicated, FX-normalised events and tokenized reference dimensions.';
CREATE SCHEMA IF NOT EXISTS wrb_ods.${market}_gold
  COMMENT 'Business signals for RMs: baselines, significant balance events, suppression, outcomes.';

-- ============================================================================================
-- SILVER
-- ============================================================================================
CREATE TABLE IF NOT EXISTS wrb_ods.${market}_silver.transactions (
  event_id             STRING    NOT NULL COMMENT 'Core banking event id; dedupe key',
  event_type           STRING    COMMENT 'TXN_POSTED | BALANCE_UPDATED',
  event_ts             TIMESTAMP NOT NULL COMMENT 'Business event time (UTC)',
  source_system        STRING,
  market               STRING,
  customer_token       STRING    NOT NULL COMMENT 'Tokenized customer id',
  account_token        STRING    NOT NULL COMMENT 'Tokenized account number',
  account_type         STRING,
  txn_id               STRING,
  direction            STRING    COMMENT 'CREDIT (inflow) | DEBIT (outflow)',
  amount               DECIMAL(20,2),
  currency             STRING,
  amount_usd           DECIMAL(20,2) COMMENT 'amount converted at ref_fx_rates as of event date',
  fx_rate_to_usd       DECIMAL(18,8),
  channel              STRING,
  booking_date         DATE,
  value_date           DATE,
  counterparty_token   STRING    COMMENT 'Tokenized counterparty account',
  counterparty_name_token STRING,
  counterparty_bank    STRING,
  narrative_token      STRING,
  balance_available    DECIMAL(20,2),
  balance_ledger       DECIMAL(20,2),
  balance_currency     STRING,
  -- lineage back to Bronze / Kafka
  bronze_source_topic  STRING,
  bronze_partition     INT,
  bronze_offset        BIGINT,
  kafka_ts             TIMESTAMP,
  bronze_ingest_ts     TIMESTAMP,
  silver_ts            TIMESTAMP COMMENT 'Time written to Silver',
  event_date           DATE GENERATED ALWAYS AS (CAST(event_ts AS DATE))
)
USING DELTA
PARTITIONED BY (event_date)
CLUSTER BY (customer_token)
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'quality' = 'silver', 'pii.classification' = 'tokenized')
COMMENT 'Silver: one row per core-banking transaction/balance event, deduplicated on event_id. Tokenized.';

CREATE TABLE IF NOT EXISTS wrb_ods.${market}_silver.transactions_quarantine (
  event_id STRING, failed_checks ARRAY<STRING>, payload STRING COMMENT 'Tokenized payload; safe to retain',
  bronze_source_topic STRING, bronze_partition INT, bronze_offset BIGINT, silver_ts TIMESTAMP
) USING DELTA COMMENT 'Events failing Silver data-quality expectations. Tokenized, so payload retained for triage.';

-- Customer dimension: tokenized, maintained by MERGE from the customer_profile topic (or a daily
-- reference load) and from CRM preference events. Flags here drive suppression.
CREATE TABLE IF NOT EXISTS wrb_ods.${market}_silver.dim_customer (
  customer_token       STRING NOT NULL,
  market               STRING,
  segment              STRING COMMENT 'e.g. PRIORITY | PRIVATE | PERSONAL',
  rm_id                STRING COMMENT 'Assigned relationship manager (staff id, not PII of a client)',
  team_id              STRING,
  preferred_language   STRING,
  do_not_contact       BOOLEAN,
  vulnerable_customer  BOOLEAN,
  open_complaints      INT,
  risk_rating          STRING,
  onboarded_date       DATE,
  valid_from           TIMESTAMP,
  updated_ts           TIMESTAMP
)
USING DELTA
TBLPROPERTIES ('quality' = 'silver', 'pii.classification' = 'tokenized')
COMMENT 'Current customer attributes keyed by token. Source of do-not-contact, vulnerability and complaint flags.';

CREATE TABLE IF NOT EXISTS wrb_ods.${market}_silver.dim_account (
  account_token        STRING NOT NULL,
  customer_token       STRING NOT NULL,
  account_type         STRING,
  currency             STRING,
  status               STRING,
  opened_date          DATE,
  updated_ts           TIMESTAMP
) USING DELTA TBLPROPERTIES ('quality' = 'silver', 'pii.classification' = 'tokenized')
COMMENT 'Account to customer mapping by token.';

CREATE TABLE IF NOT EXISTS wrb_ods.${market}_silver.ref_fx_rates (
  rate_date   DATE   NOT NULL,
  currency    STRING NOT NULL,
  rate_to_usd DECIMAL(18,8) NOT NULL COMMENT '1 unit of currency = rate_to_usd USD',
  source      STRING
) USING DELTA COMMENT 'Daily FX reference. Loaded from the bank FX feed; USD row = 1.0.';

-- ============================================================================================
-- GOLD
-- ============================================================================================
CREATE TABLE IF NOT EXISTS wrb_ods.${market}_gold.signal_rules (
  rule_key     STRING NOT NULL,
  rule_value   STRING NOT NULL,
  description  STRING,
  updated_by   STRING,
  updated_ts   TIMESTAMP
) USING DELTA COMMENT 'Data-driven thresholds and suppression parameters. WRB owns the values; no code change needed.';

MERGE INTO wrb_ods.${market}_gold.signal_rules t
USING (VALUES
  ('baseline_window_days',        '30',      'Lookback for the client norm'),
  ('baseline_exclude_hours',      '1',       'Most recent hours excluded from the baseline so the triggering event does not inflate its own norm'),
  ('baseline_min_txns',           '5',       'Below this many historical txns, fall back to absolute thresholds only'),
  ('significant_multiplier',      '30',      'Flag when amount_usd > multiplier x client avg txn (demo: 30x)'),
  ('significant_min_amount_usd',  '50000',   'Absolute floor: never flag below this'),
  ('significant_abs_amount_usd',  '250000',  'Absolute ceiling: always flag at or above this regardless of baseline'),
  ('hourly_outflow_usd',          '10000000','Rolling 1h outflow per customer that triggers a verify signal (Mario example: 10M)'),
  ('fraud_multiplier',            '100',     'Outflow above this multiple of norm is tagged fraud_flag'),
  ('max_contacts_48h',            '3',       'Suppress if RM already contacted client this many times in 2 days'),
  ('signal_ttl_hours',            '4',       'Signals expire after this many hours'),
  ('dedupe_window_minutes',       '60',      'Do not raise a second signal of the same type for the same customer within this window')
) AS s(rule_key, rule_value, description)
ON t.rule_key = s.rule_key
WHEN NOT MATCHED THEN INSERT (rule_key, rule_value, description, updated_by, updated_ts)
  VALUES (s.rule_key, s.rule_value, s.description, 'seed', current_timestamp());

CREATE TABLE IF NOT EXISTS wrb_ods.${market}_gold.client_30d_baseline (
  customer_token       STRING NOT NULL,
  direction            STRING NOT NULL COMMENT 'CREDIT | DEBIT',
  window_start         DATE,
  window_end           TIMESTAMP,
  txn_count            BIGINT,
  avg_txn_usd          DECIMAL(20,2),
  p95_txn_usd          DECIMAL(20,2),
  max_txn_usd          DECIMAL(20,2),
  avg_daily_flow_usd   DECIMAL(20,2),
  stddev_txn_usd       DECIMAL(20,2),
  as_of_ts             TIMESTAMP NOT NULL COMMENT 'When this baseline was computed'
)
USING DELTA
CLUSTER BY (customer_token)
TBLPROPERTIES ('quality' = 'gold')
COMMENT 'Per-client, per-direction norm over the trailing 30 days. Refreshed on a schedule; detection joins to the latest row.';

CREATE TABLE IF NOT EXISTS wrb_ods.${market}_gold.significant_balance_events (
  event_id             STRING NOT NULL COMMENT 'Silver event id, or synthetic id for windowed events',
  detection_type       STRING COMMENT 'SINGLE_TXN | HOURLY_OUTFLOW',
  customer_token       STRING NOT NULL,
  account_token        STRING,
  direction            STRING,
  event_ts             TIMESTAMP,
  amount_usd           DECIMAL(20,2),
  currency             STRING,
  amount               DECIMAL(20,2),
  baseline_avg_txn_usd DECIMAL(20,2),
  baseline_txn_count   BIGINT,
  baseline_as_of_ts    TIMESTAMP,
  multiple_of_norm     DECIMAL(12,2),
  trigger_rule         STRING COMMENT 'ABS_CEILING | MULTIPLIER | HOURLY_OUTFLOW',
  fraud_flag           BOOLEAN,
  counterparty_token   STRING,
  counterparty_is_new  BOOLEAN COMMENT 'No prior txn to this counterparty in baseline window',
  detected_ts          TIMESTAMP,
  -- lineage
  bronze_source_topic  STRING, bronze_partition INT, bronze_offset BIGINT, kafka_ts TIMESTAMP
)
USING DELTA
CLUSTER BY (customer_token, event_ts)
TBLPROPERTIES ('quality' = 'gold')
COMMENT 'Every event that crossed a significance threshold, before suppression. Full lineage to Kafka offset.';

CREATE TABLE IF NOT EXISTS wrb_ods.${market}_gold.rm_signals (
  signal_id            STRING NOT NULL,
  event_id             STRING NOT NULL,
  customer_token       STRING NOT NULL,
  account_token        STRING,
  rm_id                STRING,
  team_id              STRING,
  segment              STRING,
  signal_type          STRING COMMENT 'INFLOW_OPPORTUNITY | OUTFLOW_VERIFY',
  priority             STRING COMMENT 'HIGH | MEDIUM | LOW',
  fraud_flag           BOOLEAN,
  amount_usd           DECIMAL(20,2),
  currency             STRING,
  amount               DECIMAL(20,2),
  multiple_of_norm     DECIMAL(12,2),
  trigger_rule         STRING,
  status               STRING COMMENT 'CREATED | SUPPRESSED | ACTIONED | EXPIRED',
  suppression_reason   STRING COMMENT 'DO_NOT_CONTACT | VULNERABLE_CUSTOMER | ACTIVE_COMPLAINT | CONTACT_LIMIT_48H | DUPLICATE_WINDOW | NO_RM_ASSIGNED',
  preferred_language   STRING,
  open_complaints      INT,
  contacts_last_48h    INT,
  event_ts             TIMESTAMP,
  created_ts           TIMESTAMP,
  expires_at           TIMESTAMP,
  rules_snapshot       MAP<STRING, STRING> COMMENT 'Rule values in force when the signal was created',
  -- lineage
  baseline_as_of_ts    TIMESTAMP, bronze_source_topic STRING, bronze_partition INT, bronze_offset BIGINT, kafka_ts TIMESTAMP,
  signal_latency_ms    BIGINT COMMENT 'created_ts - kafka_ts: broker to signal'
)
USING DELTA
CLUSTER BY (status, rm_id, created_ts)
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'quality' = 'gold')
COMMENT 'RM-facing signals after suppression. CDF enabled so Lakebase / on-prem sinks / Kafka emit-back can consume deltas.';

CREATE TABLE IF NOT EXISTS wrb_ods.${market}_gold.signal_outcomes (
  outcome_id      STRING NOT NULL,
  signal_id       STRING NOT NULL,
  customer_token  STRING NOT NULL,
  rm_id           STRING,
  outcome         STRING COMMENT 'CONTACTED_PITCHED | CONTACTED_VERIFIED | CONTACTED_NO_ANSWER | ESCALATED_FRAUD | DISMISSED',
  product_pitched STRING,
  notes_token     STRING COMMENT 'Tokenized free text from the console',
  contacted_ts    TIMESTAMP,
  recorded_ts     TIMESTAMP
)
USING DELTA
TBLPROPERTIES ('quality' = 'gold')
COMMENT 'Written by the RM console (via Lakebase sync). Drives the contact-limit suppression and response-rate metrics.';

-- ============================================================================================
-- VIEWS (Genie / console friendly)
-- ============================================================================================
CREATE OR REPLACE VIEW wrb_ods.${market}_gold.rm_signals_active
  COMMENT 'Signals an RM can act on right now: created, not yet actioned, not expired.' AS
SELECT s.*
FROM wrb_ods.${market}_gold.rm_signals s
LEFT ANTI JOIN wrb_ods.${market}_gold.signal_outcomes o ON o.signal_id = s.signal_id
WHERE s.status = 'CREATED' AND s.expires_at > current_timestamp();

CREATE OR REPLACE VIEW wrb_ods.${market}_gold.signal_suppressions
  COMMENT 'Signals that were suppressed and why. For team-lead review of rule tuning.' AS
SELECT signal_id, customer_token, rm_id, team_id, signal_type, amount_usd, multiple_of_norm,
       suppression_reason, event_ts, created_ts
FROM wrb_ods.${market}_gold.rm_signals
WHERE status = 'SUPPRESSED';

CREATE OR REPLACE VIEW wrb_ods.${market}_gold.signal_funnel_daily
  COMMENT 'Team-lead view: signals created vs suppressed vs actioned per day and team.' AS
SELECT CAST(s.created_ts AS DATE) AS signal_date, s.team_id, s.signal_type,
       COUNT(*)                                             AS signals_total,
       SUM(CASE WHEN s.status <> 'SUPPRESSED' THEN 1 END)   AS signals_created,
       SUM(CASE WHEN s.status = 'SUPPRESSED' THEN 1 END)    AS signals_suppressed,
       COUNT(DISTINCT o.signal_id)                          AS signals_actioned,
       ROUND(COUNT(DISTINCT o.signal_id) / NULLIF(SUM(CASE WHEN s.status <> 'SUPPRESSED' THEN 1 END), 0), 3) AS response_rate,
       PERCENTILE_APPROX(s.signal_latency_ms, 0.5)          AS p50_latency_ms,
       PERCENTILE_APPROX(s.signal_latency_ms, 0.95)         AS p95_latency_ms
FROM wrb_ods.${market}_gold.rm_signals s
LEFT JOIN wrb_ods.${market}_gold.signal_outcomes o ON o.signal_id = s.signal_id
GROUP BY ALL;

CREATE OR REPLACE VIEW wrb_ods.${market}_gold.clients_vs_norm_7d
  COMMENT 'Genie: which clients moved more than N times their norm this week.' AS
SELECT t.customer_token, t.direction,
       SUM(t.amount_usd)           AS flow_7d_usd,
       b.avg_daily_flow_usd * 7    AS expected_7d_usd,
       ROUND(SUM(t.amount_usd) / NULLIF(b.avg_daily_flow_usd * 7, 0), 2) AS multiple_of_norm
FROM wrb_ods.${market}_silver.transactions t
JOIN wrb_ods.${market}_gold.client_30d_baseline b
  ON b.customer_token = t.customer_token AND b.direction = t.direction
WHERE t.event_ts >= current_timestamp() - INTERVAL 7 DAYS
  AND b.as_of_ts = (SELECT MAX(as_of_ts) FROM wrb_ods.${market}_gold.client_30d_baseline)
GROUP BY ALL;

GRANT USE SCHEMA, CREATE TABLE, MODIFY, SELECT ON SCHEMA wrb_ods.${market}_silver TO `wrb-ods-ingest-sp`;
GRANT USE SCHEMA, CREATE TABLE, MODIFY, SELECT ON SCHEMA wrb_ods.${market}_gold   TO `wrb-ods-ingest-sp`;
GRANT USE SCHEMA, SELECT ON SCHEMA wrb_ods.${market}_silver TO `wrb-ods-engineers`;
GRANT USE SCHEMA, SELECT ON SCHEMA wrb_ods.${market}_gold   TO `wrb-ods-engineers`, `wrb-rm-console-sp`;
GRANT MODIFY ON TABLE wrb_ods.${market}_gold.signal_outcomes TO `wrb-rm-console-sp`;
GRANT MODIFY ON TABLE wrb_ods.${market}_gold.signal_rules    TO `wrb-ods-rule-owners`;
