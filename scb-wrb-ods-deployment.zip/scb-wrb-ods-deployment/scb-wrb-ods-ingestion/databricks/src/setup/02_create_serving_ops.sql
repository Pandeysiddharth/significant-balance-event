-- Serving-layer operational tables. Parameters: :market
CREATE TABLE IF NOT EXISTS wrb_ods.${market}_ops.postgres_sink_audit (
  batch_id BIGINT, rows_in BIGINT, rows_upserted BIGINT, max_commit_version BIGINT,
  max_commit_ts TIMESTAMP, sink_ts TIMESTAMP,
  sink_lag_ms BIGINT COMMENT 'sink_ts - max Delta commit ts in the batch: Gold-to-Postgres lag'
) USING DELTA COMMENT 'Per micro-batch metrics for the on-prem Postgres sink.';

CREATE TABLE IF NOT EXISTS wrb_ods.${market}_ops.postgres_sink_reconciliation (
  d DATE, status STRING, gold_n BIGINT, pg_n BIGINT, gold_checksum DECIMAL(38,0), pg_checksum DECIMAL(38,0),
  match BOOLEAN, checked_ts TIMESTAMP
) USING DELTA COMMENT 'Daily Gold vs on-prem Postgres comparison.';

CREATE VOLUME IF NOT EXISTS wrb_ods.shared_ops.certs
  COMMENT 'SCB root CA for JDBC sslmode=verify-full to on-prem Postgres.';
