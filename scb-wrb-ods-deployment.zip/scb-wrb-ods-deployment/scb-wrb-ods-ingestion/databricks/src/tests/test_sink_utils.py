import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "serving"))
import sink_utils as S  # noqa: E402


class UpsertSqlTests(unittest.TestCase):
    def setUp(self):
        self.sql = S.build_upsert_sql("wrb_ods", "rm_signals", "rm_signals_staging")

    def test_targets_and_key(self):
        self.assertIn("INSERT INTO wrb_ods.rm_signals (", self.sql)
        self.assertIn("FROM wrb_ods.rm_signals_staging", self.sql)
        self.assertIn("ON CONFLICT (signal_id) DO UPDATE SET", self.sql)
        self.assertIn("SELECT DISTINCT ON (signal_id)", self.sql)

    def test_newer_commit_wins_guard(self):
        self.assertIn("WHERE EXCLUDED.commit_version > wrb_ods.rm_signals.commit_version", self.sql)

    def test_jsonb_cast_and_no_key_update(self):
        self.assertIn("rules_snapshot::jsonb AS rules_snapshot", self.sql)
        self.assertNotIn("signal_id = EXCLUDED.signal_id", self.sql)
        self.assertIn("status = EXCLUDED.status", self.sql)
        self.assertIn("synced_at = now()", self.sql)

    def test_columns_match_postgres_ddl(self):
        ddl = open(os.path.join(os.path.dirname(__file__), "..", "..", "..", "onprem-postgres", "001_schema.sql")).read()
        body = ddl.split("CREATE TABLE IF NOT EXISTS wrb_ods.rm_signals (")[1].split(");")[0]
        ddl_cols = [ln.strip().split()[0] for ln in body.splitlines()
                    if ln.strip() and not ln.strip().startswith(("--", "CONSTRAINT"))]
        for c in S.SIGNAL_COLUMNS + S.SYNC_COLUMNS:
            self.assertIn(c, ddl_cols, f"{c} missing from Postgres DDL")

    def test_columns_match_gold_ddl(self):
        ddl = open(os.path.join(os.path.dirname(__file__), "..", "setup", "01_create_silver_gold.sql")).read()
        body = ddl.split("gold.rm_signals (")[1].split("\n)\n")[0]
        for c in S.SIGNAL_COLUMNS:
            self.assertIn(c, body, f"{c} missing from gold.rm_signals DDL")


class EventTypeTests(unittest.TestCase):
    def test_inserts(self):
        self.assertEqual(S.event_type_for("insert", "CREATED"), "signal.created")
        self.assertEqual(S.event_type_for("insert", "SUPPRESSED"), "signal.suppressed")

    def test_transitions(self):
        self.assertEqual(S.event_type_for("update_postimage", "EXPIRED", "CREATED"), "signal.expired")
        self.assertEqual(S.event_type_for("update_postimage", "ACTIONED", "CREATED"), "signal.actioned")

    def test_noop_update_and_preimage_emit_nothing(self):
        self.assertIsNone(S.event_type_for("update_postimage", "CREATED", "CREATED"))
        self.assertIsNone(S.event_type_for("update_preimage", "CREATED"))
        self.assertIsNone(S.event_type_for("delete", "CREATED"))

    def test_unknown_status_emits_nothing(self):
        self.assertIsNone(S.event_type_for("insert", "WEIRD"))


class JdbcUrlTests(unittest.TestCase):
    def test_defaults_enforce_tls_and_timeouts(self):
        url = S.jdbc_url("pg.scb.internal", 5432, "ods")
        self.assertTrue(url.startswith("jdbc:postgresql://pg.scb.internal:5432/ods?"))
        self.assertIn("sslmode=verify-full", url)
        self.assertIn("statement_timeout", url)

    def test_extra_overrides(self):
        self.assertIn("sslmode=require", S.jdbc_url("h", 1, "d", {"sslmode": "require"}))


if __name__ == "__main__":
    unittest.main()
