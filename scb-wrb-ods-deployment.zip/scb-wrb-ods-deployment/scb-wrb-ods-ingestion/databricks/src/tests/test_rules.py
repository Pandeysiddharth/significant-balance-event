import os
import sys
import unittest
from decimal import Decimal as D

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "gold"))
import rules as R  # noqa: E402

RULES = R.Rules()  # defaults mirror the seed in 01_create_silver_gold.sql


class SignificanceTests(unittest.TestCase):
    def test_below_floor_never_significant(self):
        self.assertEqual(R.significance(D("49999"), D("100"), 50, RULES), (None, None))

    def test_abs_ceiling_without_baseline(self):
        trig, mult = R.significance(D("400000"), None, None, RULES)
        self.assertEqual(trig, R.ABS_CEILING)
        self.assertIsNone(mult)

    def test_multiplier_with_baseline(self):
        # 30x the norm exactly is NOT significant (strictly greater), 30.01x is
        self.assertEqual(R.significance(D("60000"), D("2000"), 20, RULES), (None, None))
        trig, mult = R.significance(D("60020"), D("2000"), 20, RULES)
        self.assertEqual(trig, R.MULTIPLIER)
        self.assertEqual(mult, D("30.01"))

    def test_insufficient_history_falls_back_to_abs(self):
        # 4 historical txns < baseline_min_txns: ignore the multiplier path
        self.assertEqual(R.significance(D("100000"), D("100"), 4, RULES), (None, None))
        self.assertEqual(R.significance(D("250000"), D("100"), 4, RULES)[0], R.ABS_CEILING)

    def test_ceiling_reports_multiple_when_baseline_known(self):
        trig, mult = R.significance(D("400000"), D("8000"), 30, RULES)
        self.assertEqual((trig, mult), (R.ABS_CEILING, D("50.00")))


class FraudAndPriorityTests(unittest.TestCase):
    def test_inflow_never_fraud(self):
        self.assertFalse(R.fraud_flag("CREDIT", D("500"), True, R.MULTIPLIER, RULES))

    def test_outflow_new_counterparty_is_fraud(self):
        self.assertTrue(R.fraud_flag("DEBIT", D("31"), True, R.MULTIPLIER, RULES))

    def test_outflow_known_counterparty_moderate_multiple_not_fraud(self):
        self.assertFalse(R.fraud_flag("DEBIT", D("31"), False, R.MULTIPLIER, RULES))

    def test_outflow_extreme_multiple_is_fraud(self):
        self.assertTrue(R.fraud_flag("DEBIT", D("100"), False, R.MULTIPLIER, RULES))

    def test_hourly_outflow_is_fraud(self):
        self.assertTrue(R.fraud_flag("DEBIT", None, False, R.HOURLY_OUTFLOW, RULES))

    def test_priority_ladder(self):
        self.assertEqual(R.priority(R.OUTFLOW_VERIFY, True, None, D("60000"), RULES), "HIGH")
        self.assertEqual(R.priority(R.INFLOW_OPPORTUNITY, False, D("61"), D("60000"), RULES), "HIGH")
        self.assertEqual(R.priority(R.INFLOW_OPPORTUNITY, False, None, D("1000000"), RULES), "HIGH")
        self.assertEqual(R.priority(R.INFLOW_OPPORTUNITY, False, D("31"), D("60000"), RULES), "MEDIUM")
        self.assertEqual(R.priority(R.INFLOW_OPPORTUNITY, False, None, D("300000"), RULES), "MEDIUM")
        self.assertEqual(R.priority(R.INFLOW_OPPORTUNITY, False, D("10"), D("60000"), RULES), "LOW")


class SuppressionTests(unittest.TestCase):
    def ok(self, **over):
        base = dict(do_not_contact=False, vulnerable_customer=False, open_complaints=0,
                    contacts_last_48h=0, duplicate_in_window=False, rm_id="RM001", fraud=False)
        base.update(over)
        return R.suppression(rules=RULES, **base)

    def test_clean_signal_raised(self):
        self.assertIsNone(self.ok())

    def test_demo_rules(self):
        self.assertEqual(self.ok(do_not_contact=True), R.DO_NOT_CONTACT)
        self.assertEqual(self.ok(vulnerable_customer=True), R.VULNERABLE_CUSTOMER)
        self.assertEqual(self.ok(open_complaints=2), R.ACTIVE_COMPLAINT)
        self.assertEqual(self.ok(contacts_last_48h=3), R.CONTACT_LIMIT_48H)
        self.assertIsNone(self.ok(contacts_last_48h=2))
        self.assertEqual(self.ok(duplicate_in_window=True), R.DUPLICATE_WINDOW)
        self.assertEqual(self.ok(rm_id=None), R.NO_RM_ASSIGNED)

    def test_order_first_match_wins(self):
        self.assertEqual(self.ok(do_not_contact=True, vulnerable_customer=True, rm_id=None), R.DO_NOT_CONTACT)

    def test_fraud_bypasses_preference_suppressions_only(self):
        self.assertIsNone(self.ok(fraud=True, do_not_contact=True, vulnerable_customer=True, open_complaints=5))
        self.assertEqual(self.ok(fraud=True, contacts_last_48h=3), R.CONTACT_LIMIT_48H)
        self.assertEqual(self.ok(fraud=True, duplicate_in_window=True), R.DUPLICATE_WINDOW)
        self.assertEqual(self.ok(fraud=True, rm_id=""), R.NO_RM_ASSIGNED)

    def test_null_flags_treated_as_false(self):
        self.assertIsNone(R.suppression(None, None, None, None, None, "RM1", False, RULES))


class RulesLoadingTests(unittest.TestCase):
    def test_from_table_rows_types_and_unknown_keys(self):
        r = R.Rules.from_table_rows({
            "significant_multiplier": "25", "max_contacts_48h": "2", "signal_ttl_hours": "6",
            "significant_abs_amount_usd": "1000000.50", "some_future_key": "x",
        })
        self.assertEqual(r.significant_multiplier, D("25"))
        self.assertEqual(r.max_contacts_48h, 2)
        self.assertEqual(r.signal_ttl_hours, 6)
        self.assertEqual(r.significant_abs_amount_usd, D("1000000.50"))
        self.assertEqual(r.baseline_window_days, 30)  # default retained

    def test_snapshot_roundtrip(self):
        snap = R.Rules().snapshot()
        self.assertEqual(R.Rules.from_table_rows(snap), R.Rules())

    def test_seed_sql_keys_match_dataclass(self):
        sql = open(os.path.join(os.path.dirname(__file__), "..", "setup", "01_create_silver_gold.sql")).read()
        import re
        seeded = set(re.findall(r"\('([a-z_0-9]+)',\s*'[^']*',", sql))
        self.assertEqual(seeded, set(R.Rules.__dataclass_fields__))


if __name__ == "__main__":
    unittest.main()
