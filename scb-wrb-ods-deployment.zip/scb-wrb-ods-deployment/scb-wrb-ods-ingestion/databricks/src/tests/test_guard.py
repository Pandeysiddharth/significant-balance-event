import json
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "ingest"))
from guard import (  # noqa: E402
    MISSING_REQUIRED_FIELD,
    MISSING_TOKENIZED_HEADER,
    NOT_JSON,
    TOKEN_FORMAT_CHECK_FAILED,
    GuardConfig,
    check_record,
    load_topic_config,
    quarantine_rate_exceeded,
)

CFG = GuardConfig(
    required_header="x-pii-tokenized",
    required_header_value="true",
    token_pattern=r"^tk_[A-Za-z0-9_-]{8,}$",
    pii_fields=["customer.id", "customer.name", "account.number", "narrative"],
    required_fields=["customer.id", "account.number"],
)
H_OK = {"x-pii-tokenized": "true"}


def payload(**over):
    base = {
        "event_time": "2026-10-21T09:12:33Z",
        "customer": {"id": "tk_9f8a7b6c5d", "name": "tk_abcdefgh12"},
        "account": {"number": "tk_0011223344"},
        "amount": 400000.00,
        "currency": "HKD",
        "narrative": "tk_zzzzzzzz99",
    }
    for k, v in over.items():
        cur = base
        parts = k.split("__")
        for p in parts[:-1]:
            cur = cur[p]
        cur[parts[-1]] = v
    return json.dumps(base)


class GuardTests(unittest.TestCase):
    def test_passes_fully_tokenized(self):
        self.assertEqual(check_record(H_OK, payload(), CFG), (None, None))

    def test_header_missing_refused(self):
        r, _ = check_record({}, payload(), CFG)
        self.assertEqual(r, MISSING_TOKENIZED_HEADER)

    def test_header_wrong_value_refused(self):
        r, _ = check_record({"x-pii-tokenized": "false"}, payload(), CFG)
        self.assertEqual(r, MISSING_TOKENIZED_HEADER)

    def test_header_case_insensitive(self):
        self.assertEqual(check_record({"x-pii-tokenized": "TRUE"}, payload(), CFG), (None, None))

    def test_clear_text_customer_id_refused_and_not_echoed(self):
        r, d = check_record(H_OK, payload(customer__id="HK12345678"), CFG)
        self.assertEqual(r, TOKEN_FORMAT_CHECK_FAILED)
        self.assertEqual(d, "customer.id")
        self.assertNotIn("HK12345678", d)

    def test_clear_text_in_optional_field_still_refused(self):
        r, d = check_record(H_OK, payload(narrative="Transfer to John Smith"), CFG)
        self.assertEqual(r, TOKEN_FORMAT_CHECK_FAILED)
        self.assertEqual(d, "narrative")

    def test_optional_field_absent_is_fine(self):
        p = json.loads(payload())
        del p["narrative"]
        self.assertEqual(check_record(H_OK, json.dumps(p), CFG), (None, None))

    def test_required_field_absent_refused(self):
        p = json.loads(payload())
        del p["account"]["number"]
        r, d = check_record(H_OK, json.dumps(p), CFG)
        self.assertEqual((r, d), (MISSING_REQUIRED_FIELD, "account.number"))

    def test_non_json_refused(self):
        self.assertEqual(check_record(H_OK, "<xml/>", CFG)[0], NOT_JSON)
        self.assertEqual(check_record(H_OK, None, CFG)[0], NOT_JSON)
        self.assertEqual(check_record(H_OK, "[1,2]", CFG)[0], NOT_JSON)

    def test_non_string_pii_value_refused(self):
        r, _ = check_record(H_OK, payload(customer__id=12345678), CFG)
        self.assertEqual(r, TOKEN_FORMAT_CHECK_FAILED)

    def test_quarantine_alarm(self):
        self.assertFalse(quarantine_rate_exceeded(0, 0, CFG))
        self.assertFalse(quarantine_rate_exceeded(1000, 10, CFG))
        self.assertTrue(quarantine_rate_exceeded(1000, 11, CFG))

    def test_config_loads_and_matches_bridge(self):
        here = os.path.dirname(os.path.abspath(__file__))
        tc = load_topic_config(os.path.join(here, "..", "config", "topics.yml"),
                               "hk", "wrb.ods.hk.core_banking.tokenized")
        self.assertEqual(tc.bronze_table, "wrb_ods.hk_bronze.core_banking_events")
        self.assertEqual(tc.quarantine_table, "wrb_ods.hk_ops.bronze_quarantine")
        self.assertTrue(tc.checkpoint_path.startswith("/Volumes/wrb_ods/hk_ops/checkpoints/bronze/"))
        # Guard fields must match the bridge SMT config for the same topic
        with open(os.path.join(here, "..", "..", "..", "bridge", "solace-source-connector.json")) as fh:
            bridge = json.load(fh)["config"]
        self.assertEqual(bridge["kafka.topic"], tc.topic)
        self.assertEqual(bridge["transforms.tokenizePii.fields"].split(","), tc.guard.pii_fields)
        self.assertEqual(bridge["transforms.tokenizePii.fields.required"].split(","), tc.guard.required_fields)
        self.assertEqual(bridge["transforms.markTokenized.header"], tc.guard.required_header)


if __name__ == "__main__":
    unittest.main()
