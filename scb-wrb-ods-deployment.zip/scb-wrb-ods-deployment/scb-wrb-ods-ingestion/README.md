# WRB ODS — Release 1 pipeline (Bronze / Silver / Gold / Serving)

## Part 1 — Ingestion (Option 1: tokenize at the bridge)

Solace → **tokenize on-prem** → Kafka → MirrorMaker 2 → Azure Kafka → Databricks Structured Streaming → **Bronze (tokenized only)**

Clear-text PII never leaves SCB's on-prem estate, in flight or at rest. Databricks holds no detokenization capability.

```
ON-PREM                                                            AZURE (SCB VNet)
───────                                                            ────────────────
Core banking ─► Solace ─► Kafka Connect ──► Kafka topic           MM2        Kafka topic          Databricks job
                 queue    Solace Source     wrb.ods.hk.           ───────►   (same name,          bronze_ingest.py
                          connector         core_banking.                    OAuth, Private       │  guard: header + token
                          + TokenizePII     tokenized                        Link)                │  pattern + required fields
                          SMT (calls SCB    header: x-pii-                                        ├─► wrb_ods.hk_bronze.core_banking_events
                          tokenization      tokenized=true                                        ├─► wrb_ods.hk_ops.bronze_quarantine (hash only)
                          service)                                                                └─► wrb_ods.hk_ops.bronze_ingest_audit
                               │
                               └─ on error ─► wrb.ods.hk.core_banking.bridge_dlq.CLEAR   (never mirrored)
```

## Layout

```
bridge/
  solace-source-connector.json                  Core-banking queue → Kafka, SMT chain tokenizePii → markTokenized
  solace-source-connector-customer-profile.json Customer-profile / CRM-preference queue, same SMT (accounts[].number fan-out)
  tokenize-smt/                                 Custom SMT (Java 17). Batch-calls tokenization service, LRU cache, fail-closed
  mirror-maker2.properties                      Replicates ONLY *.tokenized topics on-prem → Azure; *.CLEAR / *dlq* excluded
databricks/
  databricks.yml                                Asset bundle (dev / uat / prod, run as service principal)
  resources/bronze_ingest_job.yml               Setup job (00 + 01 DDL), continuous Bronze job (task per topic), warehouse, alerts
  resources/silver_gold_jobs.yml                Continuous Silver/Gold streams, 15-min baseline refresh, 5-min housekeeping, alerts
  src/setup/00_create_catalog.sql               Catalog, <mkt>_bronze / <mkt>_ops, Bronze tables, quarantine, audit, grants
  src/setup/01_create_silver_gold.sql           Silver + Gold tables, rules seed, Genie/console views, grants
  src/config/topics.yml                         Topic → table map and guard config per market
  src/ingest/guard.py, bronze_ingest.py         Bronze: fail-closed tokenization guard, quarantine, audit
  src/silver/dq.py                              Data-quality expectations as plain SQL predicates
  src/silver/silver_transactions.py             Parse → dedupe within watermark → DQ → FX to USD → silver.transactions
  src/silver/silver_dimensions.py               MERGE dim_customer / dim_account from profile events
  src/gold/rules.py                             Spark-free significance / fraud / priority / suppression rules
  src/gold/baseline_refresh.py                  Trailing-30d per-client norm (excludes last hour), atomic replace
  src/gold/signal_detection.py                  Stream Silver → significant_balance_events → rm_signals
  src/gold/signal_housekeeping.py               CREATED → ACTIONED / EXPIRED transitions
  src/serving/sink_utils.py                     Spark-free: upsert SQL builder, CDF → event-type mapping, JDBC URL
  src/serving/postgres_sink.py                  CDF stream gold.rm_signals → staging → transactional upsert on-prem
  src/serving/kafka_emit.py                     CDF stream → signal.created/suppressed/expired/actioned on SCB topic
  src/serving/outcomes_ingest.py                Reverse path: Bronze outcome events → gold.signal_outcomes
  src/serving/reconcile.py                      Daily Gold vs Postgres count + checksum comparison
  src/setup/02_create_serving_ops.sql           Sink audit + reconciliation tables, CA cert volume
  resources/serving_jobs.yml                    Continuous serving streams, nightly reconcile, 3 alerts
  src/tests/                                    42 tests: guard (12) + rules (19) + sink (11), incl. DDL ↔ code checks
onprem-postgres/
  001_schema.sql                                wrb_ods schema: rm_signals mirror, UNLOGGED staging, watermark, outcomes outbox, roles
  002_token_resolution.sql                      customer/account token maps + resolved views for the API (join, no detokenize call)
```

## Controls (what the security review will ask)

| Control | Where | Behaviour |
|---|---|---|
| Tokenize before leaving on-prem | `TokenizePII` SMT | Configured JSON paths replaced with tokens from SCB's service, deterministic scheme. Required fields missing → record fails |
| Clear-text never mirrored | `mirror-maker2.properties` | Allow-list regex matches only `wrb.ods.<mkt>.<family>.tokenized`; explicit exclude for `.CLEAR` and `dlq` |
| Bridge DLQ stays on-prem | connector `errors.deadletterqueue.topic.name` | Suffix `.CLEAR` so the MM2 exclude catches it. Contains clear text by definition; access restricted to bridge ops |
| Fail-closed landing guard | `guard.check_record` | Bronze write only if header `x-pii-tokenized=true` **and** every present PII field matches the token regex **and** required fields present |
| Quarantine carries no payload | `split_good_bad` | Coordinates + SHA-256 + reason. Replay from the on-prem topic after fixing the bridge |
| Guard never echoes values | `check_record` | `detail` is the field path, never the value |
| Config drift fails closed | `test_config_loads_and_matches_bridge` | CI asserts bridge SMT fields == guard PII fields for each topic |
| Exactly-once | checkpoint + `txnAppId/txnVersion` | Kafka offsets in checkpoint; idempotent appends to Bronze, quarantine and audit per batch |
| Least privilege | grants in `00_create_catalog.sql` | Ingest SP writes; engineers read Bronze; only platform ops read `_ops` |

## Deployment order

**On-prem (SCB Kafka / bridge team)**
1. Agree with the tokenization team: endpoint, deterministic scheme name, token format regex. Update `service.scheme` in the connector and `token_pattern` in `topics.yml`.
2. `mvn package` in `bridge/tokenize-smt`, drop the jar into the Connect plugin path, restart workers.
3. Create topics `wrb.ods.hk.core_banking.tokenized` and `wrb.ods.hk.core_banking.bridge_dlq.CLEAR` (restricted ACLs on the latter).
4. `POST /connectors` with `solace-source-connector.json`. Verify a sample record: PII fields are tokens, `_tokenization_scheme` is stamped, header present.
5. Start MM2 with `mirror-maker2.properties`. Verify the tokenized topic appears on the Azure cluster and the `.CLEAR` topic does **not**.

**Azure / Databricks (Sid + WRB engineers)**
6. Secrets in scope `wrb-ods`: `kafka_bootstrap`, `kafka_oauth_client_id`, `kafka_oauth_client_secret`, `kafka_oauth_token_endpoint`, `kafka_oauth_scope`.
7. `databricks bundle validate -t dev` then `databricks bundle deploy -t dev --var market=hk --var storage_root=abfss://... --var ingest_sp=<app-id>`.
8. `databricks bundle run wrb_ods_bronze_setup -t dev` (creates catalog objects).
9. `databricks bundle run wrb_ods_bronze_ingest -t dev` (continuous). Watch `bronze_ingest_audit.max_latency_ms`; target is well under 60 s for the Architect view, the alert fires above it.

**Smoke test**
10. Publish three test events to the Solace queue: fully tokenized-able, one with a missing `account.number`, one non-JSON. Expect 1 row in Bronze, 1 in bridge DLQ (missing required field fails in the SMT), 1 in bridge DLQ (not JSON). Then publish one directly to the Azure Kafka topic without the header to confirm the Databricks guard quarantines it.

## Portability (China / non-cloud markets)

`guard.py` has no Spark or Databricks dependency. `bronze_ingest.py` uses only open Structured Streaming APIs and Delta; the Databricks-specific parts are `dbutils.secrets` (swap for env vars / vault client) and the `kafkashaded.` prefix on the Kafka OAuth classes (drop the prefix on OSS Spark). `txnAppId/txnVersion` idempotent writes work on Delta OSS ≥ 2.x.

## Open items for the joint platform session

- Kafka on Azure: SCB-run cluster behind Private Link vs Event Hubs Kafka endpoint. The config here assumes the former; for Event Hubs change `azure.bootstrap.servers` to `<ns>.servicebus.windows.net:9093` and the OAuth scope to `https://<ns>.servicebus.windows.net/.default`.
- Token format: the `tk_` prefix regex is a placeholder until the tokenization team confirms the real format.
- Bridge DLQ handling: who owns replay from `.CLEAR` and the SLA, given it holds clear text.
- Retention on the on-prem tokenized topic: this is the raw record of truth for replay now that Bronze is tokenized. Size it for the replay window WRB wants (suggest ≥ 7 days).
- SMT throughput: one HTTP batch call per record on cache miss. If the tokenization service P99 is above ~50 ms, move to a micro-batching SMT or pre-tokenize via a stream processor in front of the connector.


---

## Part 2 — Silver and Gold

```
bronze.core_banking_events ──► silver.transactions ──────────────┐
   (tokenized JSON)            typed · deduped on event_id       │ stream
                               DQ → transactions_quarantine      ▼
                               amount_usd via ref_fx_rates   gold.signal_detection (foreachBatch, 2 s)
                                                                 │ joins per batch to latest:
bronze.customer_profile_events ─► silver.dim_customer            │   client_30d_baseline  (refreshed /15 min)
                                  silver.dim_account             │   dim_customer flags
                                  (MERGE, latest wins)           │   signal_outcomes 48h  (from console)
                                                                 │   rm_signals in dedupe window
                                                                 │   signal_rules
                                                                 ├─► gold.significant_balance_events  (pre-suppression, lineage to Kafka offset)
                                                                 └─► gold.rm_signals  CREATED | SUPPRESSED (+ reason)
                                                                        │  housekeeping /5 min → ACTIONED | EXPIRED
                                                                        ▼
                                                                 views: rm_signals_active · signal_suppressions · signal_funnel_daily · clients_vs_norm_7d
```

### Silver

| Step | Behaviour |
|---|---|
| Parse | `from_json` with the explicit canonical schema (`EVENT_SCHEMA`). PII paths match the bridge SMT config exactly |
| Dedupe | `withWatermark(event_ts, 2h)` + `dropDuplicatesWithinWatermark(event_id)`: redelivery from Solace, the bridge or MM2 yields one Silver row |
| DQ | 10 expectations in `dq.py` (presence, parseable/non-future/non-stale timestamps, direction, positive amount, ISO currency). Failures → `transactions_quarantine` with the tokenized payload retained |
| FX | Stream-static join to `ref_fx_rates` on event date; falls back to the latest known rate for the currency; USD = 1.0. `amount_usd` is what every Gold threshold uses, so HK, SG and India share one rules table |
| Dimensions | `dim_customer` carries `rm_id`, `team_id`, `do_not_contact`, `vulnerable_customer`, `open_complaints`, `preferred_language`. `dim_account` maps account token → customer token. MERGE keeps the latest profile event per customer |

### Gold

**Baseline** (`client_30d_baseline`): per `customer_token × direction`, trailing `baseline_window_days`, excluding the last `baseline_exclude_hours` so the event under test doesn't inflate its own norm. Batch every 15 minutes, atomic overwrite; detection reads the newest snapshot each micro-batch. Below `baseline_min_txns` of history, only absolute thresholds apply.

**Significance** (`rules.significance`): below `significant_min_amount_usd` → never; at/above `significant_abs_amount_usd` → `ABS_CEILING`; otherwise `amount_usd > significant_multiplier × avg_txn_usd` (demo: 30×) → `MULTIPLIER`. Plus `HOURLY_OUTFLOW`: rolling 1-hour debit sum per customer above `hourly_outflow_usd` (Mario's "outflow in the past hour > 10M").

**Signal typing**: CREDIT → `INFLOW_OPPORTUNITY`; DEBIT → `OUTFLOW_VERIFY`. `fraud_flag` on outflows to a counterparty not seen in the baseline window, ≥ `fraud_multiplier` × norm, or any hourly burst. Priority HIGH / MEDIUM / LOW from fraud flag, multiple and absolute size.

**Suppression** (`rules.suppression`, first match wins): `DO_NOT_CONTACT` → `VULNERABLE_CUSTOMER` → `ACTIVE_COMPLAINT` → `CONTACT_LIMIT_48H` (`max_contacts_48h`, demo 3× in 2 days) → `DUPLICATE_WINDOW` (`dedupe_window_minutes`) → `NO_RM_ASSIGNED`. Fraud-flagged outflows bypass the three preference-based suppressions (verifying intent protects the client) but still respect contact limit, dedupe and RM assignment. Suppressed signals are still written, with `status='SUPPRESSED'` and the reason, so team leads can tune rules against real volumes.

**Expiry**: `expires_at = created_ts + signal_ttl_hours` (demo 4h). `rm_signals_active` filters live; housekeeping materialises `EXPIRED`/`ACTIONED` so CDF consumers see the transition.

**Rules are data**: `gold.signal_rules` is seeded by the DDL and owned by `wrb-ods-rule-owners`. Every signal stores `rules_snapshot`, the values in force when it was raised. `test_seed_sql_keys_match_dataclass` fails CI if the seed and the code disagree.

**Lineage**: every signal carries `event_id → bronze_source_topic/partition/offset → kafka_ts` and `baseline_as_of_ts`, plus `signal_latency_ms` (broker → signal) which feeds the Architect view and the P95 < 5 min alert.

### Deployment (after Part 1)

1. `databricks bundle run wrb_ods_bronze_setup -t dev` now also runs `01_create_silver_gold.sql`.
2. Load `silver.ref_fx_rates` from the bank FX feed (daily job, not included; a single `USD,1.0` row is enough to smoke-test).
3. Deploy the second bridge connector so `customer_profile_events` lands; `wrb_ods_silver_gold_streams` will otherwise raise signals with `NO_RM_ASSIGNED`.
4. `databricks bundle run wrb_ods_gold_baseline_refresh -t dev` once, then start `wrb_ods_silver_gold_streams`.
5. Smoke test: replay the demo 400K HKD transfer on the Solace queue. Expect one row in `significant_balance_events` (`ABS_CEILING` if HKD→USD ≥ 250K, else `MULTIPLIER` against the client's norm) and one `rm_signals` row with `status='CREATED'`, `signal_latency_ms` well under 60 000.

### Open items for WRB

- Threshold values in `signal_rules` are demo defaults in USD; WRB rule owners should set them per segment (a later extension: key rules by segment).
- `dim_customer` assumes a profile/preference topic exists on Solace. If preferences live only in CRM, swap `silver_dimensions.py` for a scheduled load from the CRM extract, same MERGE.
- `HOURLY_OUTFLOW` uses wall-clock `current_timestamp()` for the window; for replay/backfill runs switch it to the batch's max `event_ts`.
- `signal_outcomes` is written by the console through Lakebase sync (Part 3, serving layer); until then the contact-limit suppression is effectively off.


---

## Part 3 — Serving: Gold → on-prem Postgres (and back)

```
AZURE (Databricks)                                              ON-PREM (SCB)
──────────────────                                              ─────────────
gold.rm_signals  (Delta, CDF on)
   │
   ├─ postgres_sink.py ── JDBC (private path, TLS verify-full) ──► wrb_ods.rm_signals_staging  (UNLOGGED, truncate per batch)
   │     collapse CDF → latest change per signal_id                       │ one transaction
   │     commit_version carried on every row                              ▼
   │                                                               wrb_ods.rm_signals  ◄── upsert, newer commit_version wins
   │                                                               wrb_ods.sync_watermark
   │                                                                      │ join on token (no service call)
   │                                                               wrb_ods.customer_token_map ── ods.customer_master
   │                                                                      ▼
   │                                                               v_rm_signals_active_resolved  ──► SpringWatch API ──► RM
   │
   └─ kafka_emit.py ──► wrb.ods.hk.signal_events ── MM2 azure→onprem ──► Solace/Kafka subscribers (Fusion, CRM, SpringWatch)
                        signal.created | suppressed | expired | actioned (tokenized, keyed by customer_token)

REVERSE  RM outcome ──► wrb_ods.signal_outcomes_outbox ──► SCB publisher ──► Solace ──► bridge (tokenize notes)
         ──► wrb.ods.hk.signal_outcomes.tokenized ──► MM2 ──► Bronze ──► outcomes_ingest.py ──► gold.signal_outcomes
         (closes the "contacted 3× in 48h" suppression loop; housekeeping marks the signal ACTIONED)
```

### Why CDF + upsert, not a direct streaming JDBC write

- **Status transitions are updates.** CREATED → ACTIONED/EXPIRED must reach Postgres as row updates; CDF gives insert and update_postimage rows with a commit version, so the sink is a plain upsert.
- **Idempotent by construction.** Every row carries the Delta `commit_version`; the upsert's `WHERE EXCLUDED.commit_version > target.commit_version` makes replayed batches and out-of-order retries no-ops. A failed batch is thrown, the stream retries from the checkpoint, nothing double-applies.
- **One transaction per batch.** Staging via parallel Spark JDBC writers (fast), then upsert + watermark in a single JDBC transaction on the driver (atomic). Postgres readers never see a half-applied batch.
- **Separate checkpoints** for the Postgres sink and the Kafka emit: an on-prem outage stalls one, not both.

### Token resolution on-prem

Databricks never detokenizes. `002_token_resolution.sql` creates `customer_token_map` / `account_token_map`, populated once by SCB tokenizing its own master with the same deterministic scheme the bridge uses. `v_rm_signals_active_resolved` is the API's read model: tokens join to clear attributes in the ODS. `v_unresolved_signal_tokens` surfaces customers whose signal arrived before the map was updated (or scheme drift); alert on it. The `wrb_ods_sync` role (Databricks) is explicitly revoked from the map tables.

### Monitoring

| Signal | Source | Alert |
|---|---|---|
| Gold → Postgres lag | `postgres_sink_audit.sink_lag_ms` | > 60 s |
| Sink stalled | no audit row for 30 min | page |
| Gold vs Postgres drift | nightly `reconcile.py` (counts + checksum per day/status) | any mismatch |
| Unresolved tokens | `v_unresolved_signal_tokens` (on-prem) | SCB-side alert |

Recovery from drift: `postgres_sink.py --trigger-mode available_now --starting-version <first bad commit>`; the commit-version guard makes the replay safe.

### Deployment (after Parts 1–2)

1. Platform session outputs: private endpoint / firewall allow-list for Databricks → Postgres :5432; SCB root CA uploaded to `/Volumes/wrb_ods/shared_ops/certs/scb-root-ca.pem`; secrets `pg_host`, `pg_port`, `pg_database`, `pg_user` (= `wrb_ods_sync`), `pg_password`.
2. On-prem DBA runs `001_schema.sql` then `002_token_resolution.sql`; SCB job populates the token maps from the customer master.
3. Create Azure topic `wrb.ods.hk.signal_events`; add the `azure->onprem` MM2 flow (already in `mirror-maker2.properties`, restricted to that topic pattern).
4. Deploy the outcomes bridge connector (`solace-source-connector-signal-outcomes.json`) and the outbox publisher (SCB-owned: drain `signal_outcomes_outbox WHERE published_ts IS NULL` to Solace, set `published_ts`).
5. `databricks bundle deploy` picks up `serving_jobs.yml`; start `wrb_ods_serving_streams`.
6. Smoke test: raise one signal (replay the 400K event). Expect the row in `wrb_ods.rm_signals` within seconds, visible through `v_rm_signals_active_resolved` with clear name, a `signal.created` event on the on-prem topic, and after inserting an outcome in the outbox: `gold.signal_outcomes` row, then `status = 'ACTIONED'` in both Gold and Postgres and a `signal.actioned` event.

### Decisions still open for Habeeb / Dhas

- **Pattern approval**: this is the "Databricks writes to a business-application database" case. The sink role has write access only to staging, the mirror table and the watermark; nothing else in the ODS.
- **Postgres as mirror vs system of record for signals**: the design keeps Gold authoritative and Postgres a mirror (reconciled nightly). If WRB wants Postgres authoritative, the outbox pattern already covers outcomes; signals would stay Databricks-born either way.
- **Lakebase**: the same CDF stream can feed a Lakebase synced table for the Databricks App console with no extra code; the Postgres path is for on-prem consumers. Both can run in parallel.
- **If JDBC is blocked at the network layer**: `kafka_emit.py` already carries the full signal row. An on-prem consumer can upsert into `rm_signals` from the topic using the same `build_upsert_sql` statement, making Kafka the sole transport.
